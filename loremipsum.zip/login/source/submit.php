<?php
session_start();
if (!isset($_SESSION["blocked"])){include $_SERVER['DOCUMENT_ROOT'].'/source/blacklist/check.php';}
if($_SESSION["blocked"]===true){exit('window.location = "/DDoS.php";'); }

if (!isset($_SESSION["client_username"]) ) {exit("Error 400. Username not defined."); }
if (!isset($_SESSION["client_id"]) ) {exit("Error 400. Client ID not defined."); }

if(!isset($_POST["q"])){exit("Error 400. Password not defined.");}else{$q = $_POST["q"];}
if (!isset($_POST["r"]) ){exit("Error 400. Cookie settings not defined.");} //$_POST["r"] is string type

if (!isset($_SESSION["passwordAttempt"]) ) {$_SESSION["passwordAttempt"]=0; }
$_SESSION["passwordAttempt"]++;
if ($_SESSION["passwordAttempt"]==5){
	include $_SERVER['DOCUMENT_ROOT'].'/source/blacklist/blacklist.php';
	$_SESSION["blocked"]=true; unset($_SESSION["passwordAttempt"]);
	exit('window.location = "/DDoS.php";');
}

if (
	preg_match("/[^\w\d\@\#\:\.\/]/",$q)||strlen($q)<5|| strlen($q)>32||
	!preg_match("/[a-z]/",$q)|| !preg_match("/[A-Z]/",$q)||
	!preg_match("/[\d]/",$q)|| !preg_match("/[\@\#\:\.\/\_]/",$q)
	){	exit('elem.className="show";
		document.getElementById("passwordAttempt").innerText='.$_SESSION["passwordAttempt"].';');
	}
else{
	$conn =	new mysqli("103.21.58.5:3306","loremipsum","##@LoremIpsum@##","loremipsum") 
	or exit("Error Connection failed: " . $conn->connect_error);
	$result = $conn->query("
		SELECT id FROM login WHERE 
		id=".$_SESSION["client_id"]." AND 
		username='".$_SESSION["client_username"]."' AND 
		password='".$q."';"
		);		
	$conn->close();
	if($result->num_rows===0){
		exit('elem.className="show";
			document.getElementById("passwordAttempt").innerText='.$_SESSION["passwordAttempt"].';');
	}
	else if($result->num_rows===1){
		if($_POST["r"]=="true"){
			$t=time()+1*365.25*24*3600;
			setcookie("client_username", $_SESSION["client_username"], $t, '/'); //for autologin
			setcookie("client_password", $q, $t, '/'); //for autologin
		}else if($_POST["r"]=="false"){$t=0;}
		else{exit("Error 500. Cookie settings not well defined.");}
		
		setcookie("h_off", $_SESSION["h_off"],$t, '/');
		setcookie("client_name", $_SESSION["client_name"],$t, '/');
		$client_id = $_SESSION["client_id"];
		$client_rank = $_SESSION["client_rank"];
		$client_ida = $_SESSION["client_ida"];

		session_unset();session_destroy();
		session_set_cookie_params(0);session_start(); //store till browser close
		$_SESSION["client_id"] = $client_id;
		$_SESSION["client_rank"] = $client_rank;
		$_SESSION["client_ida"] = $client_ida;

		/* for debugging
		echo 	"console.log('".
				$t."-".
				$_COOKIE['h_off']."-".
				$_COOKIE['client_name']."-".
				$_SESSION['client_id']."-".
				$_SESSION["client_rank"]."-".
				$_SESSION["client_ida"].
			"')"; 
		*/
		echo 'window.location = "/i/";';
	} else{exit("Error 400. Account not defined."); } //rows != 1,else
}//regex else

exit(0);

?>