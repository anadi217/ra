<?php
session_start();
if (!isset($_SESSION["blocked"])){include $_SERVER['DOCUMENT_ROOT'].'/source/blacklist/check.php';}
if($_SESSION["blocked"]===true){exit('window.location = "/DDoS.php";'); }

if( !isset($_POST["q"]) ){exit("Error 400. Username not defined.");}else{$q = $_POST["q"];}

if ( !isset($_SESSION["usernameAttempt"]) ) {$_SESSION["usernameAttempt"]=0; }
$_SESSION["usernameAttempt"]++;
if ($_SESSION["usernameAttempt"]==3){
	include $_SERVER['DOCUMENT_ROOT'].'/source/blacklist/blacklist.php';
	$_SESSION["blocked"]=true; unset($_SESSION["usernameAttempt"]);
	exit('window.location = "/DDoS.php";');
}

if (preg_match("/^[a-zA-Z][a-zA-Z\d]*[\._]?[a-zA-Z\d]+$/",$q) && strlen($q)>5 && strlen($q)<32 ){
	$conn =	new mysqli("103.21.58.5:3306","loremipsum","##@LoremIpsum@##","loremipsum") 
	or die("Error Connection failed: " . $conn->connect_error);
	$result = $conn->query("SELECT id FROM login WHERE username='".$q."';");
	$conn->close();
	if($result->num_rows===0){echo 'elem.className="show";'; }
	else if($result->num_rows===1){
		unset($_SESSION["usernameAttempt"]);
		$row = $result->fetch_assoc();
		$_SESSION["client_id"] = (int)$row["id"];
		$_SESSION["client_username"]=$q; //will use this for passwordCheck

		echo 'document.getElementById("usernameWindow").remove();';
		echo 'document.getElementById("passwordWindow").style.display="block";';
		echo 'document.getElementById("password").focus();';
		echo 'loginDetails(); ';
	}
}else{exit("error 500");}
?>