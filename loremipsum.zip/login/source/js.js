if (window.XMLHttpRequest) {xmlhttp = new XMLHttpRequest();} 
else {xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");}

var remember=true;
function check(elem) {
	if(elem.className=="checked"){elem.className="";remember=false;}
	else{elem.className="checked";remember=true;}
}

function loginDetails() {
	var loginName = document.getElementById("loginName");
	var loginRank = document.getElementById("loginRank");
	xmlhttp.onreadystatechange = function() {
		if (this.readyState==4 && this.status==200) {
			var t = this.responseText;
			if(t.toLowerCase().indexOf("error")>-1){console.log(t);}
			else{eval(t);}				
		}
	}
	xmlhttp.open("GET","source/loginDetails.php");
	xmlhttp.send();
}

var busy=false;
function loginUsername() {
	if (!busy) {
		busy=true;
		var q=document.getElementById("username").value;
		var elem = document.getElementById("usernameWrong");
		document.getElementById('loginUsername').innerHTML="&nbsp;";
		document.getElementById('loginUsername').className="loading";
		elem.className=""; var reg = /^[a-zA-Z][a-zA-Z0-9]*[\._]?[a-zA-Z0-9]+$/;
		if(q.length<6||!reg.test(q)){
			elem.className="show";
			document.getElementById("loginUsername").className="";
			document.getElementById("loginUsername").innerHTML="Next";
		}
		else{
			xmlhttp.onreadystatechange = function() {
				if (this.readyState==4 && this.status==200) {
					var t = this.responseText;
					if(t.toLowerCase().indexOf("error")>-1){console.log(t);}
					else{eval(t);} busy=false; var b=null;
					if(b=document.getElementById("loginUsername")){b.className=""; b.innerHTML="Next"; }				
				}
			}
			xmlhttp.open("POST","source/loginUsername.php",true);
			xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
			xmlhttp.send("q="+q);
		}
	}
}


function submit() {
	if (!busy) {
		busy=true;
		var q=document.getElementById("password").value;
		var elem = document.getElementById("passwordWrong");
		document.getElementById('submit').innerHTML="&nbsp;";
		document.getElementById('submit').className="loading";
		elem.className="";
		xmlhttp.onreadystatechange = function() {
			if (this.readyState==4 && this.status==200) {
				var t = this.responseText;
				if(t.toLowerCase().indexOf("error")>-1){console.log(t);}
				else{eval(t);} busy=false;
				document.getElementById("submit").className="";
				document.getElementById("submit").innerHTML="Next";
			}
		}
		xmlhttp.open("POST","source/submit.php",true);
		xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
		xmlhttp.send("q="+q+"&r="+remember);
	}
}


