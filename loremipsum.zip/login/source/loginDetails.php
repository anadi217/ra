<?php
session_start();
if (!isset($_SESSION["blocked"])){include $_SERVER['DOCUMENT_ROOT'].'/source/blacklist/check.php';}
if($_SESSION["blocked"]===true){exit('window.location = "/DDoS.php";'); }

if(!isset($_SESSION["client_id"])){exit("Error 400. Bad Client ID.");}

$conn =	new mysqli("103.21.58.5:3306","loremipsum","##@LoremIpsum@##","loremipsum") 
or die("Error Connection failed: " . $conn->connect_error);
$result = $conn->query("SELECT ida, name, rank, h_off FROM account WHERE id=".$_SESSION["client_id"].";");
if($result->num_rows===1){
	$row = $result->fetch_assoc();

	$_SESSION["h_off"]=$row["h_off"];
	$_SESSION["client_name"] = $row['name'];
	echo "loginName.innerHTML='".$row['name']."';";

	$r = (int)$row["rank"]; //converts bit value to integer
	//echo "console.log(".$r.");";
	if($r===1){ //author
		$_SESSION["client_rank"] = 1;
		$_SESSION["client_ida"] = $row['ida'];
		echo "loginRank.innerHTML='Author';";
	}
	else if($r===2){ //admin
		$_SESSION["client_rank"] = 2;
		$_SESSION["client_ida"] = 0;
		echo "loginRank.innerHTML='Adminstrator';";
	}else if($r===3){ //requested to be author (late addition)
		$_SESSION["client_rank"] = -1;
		$_SESSION["client_ida"] = 0;
	}else{
		$_SESSION["client_rank"] = 0;
		$_SESSION["client_ida"] = 0;
	}

}
else{exit("Error 400. Bad Client ID.");}

exit(0);

/*
values saved so far
-------------------
id 			-	$_SESSION["client_id"] 	{during loginUsername.php}
username 	-	$_SESSION["client_username"] {during loginUsername.php}
h_off 		-	$_SESSION["h_off"]
name 		-	$_SESSION["client_name"] 
rank 		-	$_SESSION["client_rank"]  => 0 for readers, 1 for authors, 2 for admins
ida 		-	$_SESSION["ida"] => non zero for authors, zero for others

*/


?>