<?php 
session_start();
if(!isset($_SESSION["blocked"])){session_unset();session_destroy();}
else{
	if($_SESSION["blocked"]==true){header("Location: /DDoS.php");}
	else if($_SESSION["blocked"]==false){session_unset();session_destroy();}
}
foreach ($_COOKIE as $key => $value) {setcookie($key,false,0,"/");}
$root = $_SERVER['DOCUMENT_ROOT']; include $root.'/source/common/phpHead.php';
?>

<!DOCTYPE html>
<html>
<head>
	<?php include $root.'/source/common/htmlHead.php';?>
	<title>Login : Lorem Ipsum</title>
	<link rel="stylesheet" type="text/css" href="source/css.css">
	<script type="text/javascript" src="source/js.js"></script>
</head>
<body>
<?php include $root.'/source/common/bodyTop.php';?>
<div id="bodyflex">
	<div id="loginTitle" onclick="window.location.reload(true);">
		Welcome to<br><span style="font-size:1.5em;">Lorem Ipsum</span>
	</div>
	<div id="usernameWindow">
		<div id="login">Login</div>
		<div id="usernameDiv">
			<img src="img/login.svg">
			<input type="text" autofocus id="username" maxlength="31" 
			onkeydown="if(event.keyCode==13){loginUsername();}">
		</div>
		<div id="usernameWrong">Incorrect Username</div>
		<div style="text-align:center;">
			<div id ="loginUsername" onclick="loginUsername();">Next</div>
		</div>
		<div id="createaccount"><a href="/signup/">Create an account?</a></div>
	</div>
	
	<div id="passwordWindow" style="display:none;">
		<div id="backarrow" onclick="window.location.reload(true);"><img src="/source/img/back.svg"></div>
		<div id="loginInfo">
			<img id="loginImg" src="/source/img/account.svg">
			<div>
				<p id="loginName"></p>
				<span id="loginRank"></span>
			</div>	
		</div>
		<div id="passwordDiv">
			<img src="img/password.svg">
			<input type="password" id="password" maxlength="31"
			onkeydown="if(event.keyCode==13){submit();}">
		</div>
		<div id="passwordWrong">Incorrect Password: Attempt <span id="passwordAttempt"></span></div>
		<div id="rememberMeDiv">
			<div id="checkbox" class="checked" onclick="check(this);"></div> Remember Me
		</div>
		<div style="text-align:center;"><div id ="submit" onclick="submit();">Login</div></div>
		<div id="resetpassword"><a href="/signup/reset.php">Forgot password?</a></div>
	</div>
</div>
<?php include $root.'/source/common/bodyBottom.php';?>
</body>
</html>