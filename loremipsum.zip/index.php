<?php $root = $_SERVER['DOCUMENT_ROOT'];?>
<!DOCTYPE html>
<html>
<head>
	<?php include $root.'/source/common/htmlHead.php';?>
	<title>Lorem ipsum dolor sit amet</title>
	<link rel="stylesheet" type="text/css" href="source/css.css">
	<script type="text/javascript" src="source/js.js"></script>
</head>
<body>
<!--button onclick="window.location.reload(true);" style="position: absolute; z-index: 100;">Refresh</button!-->
<?php include $root.'/source/common/bodyTop.php';?>
<div id="mainPageCarousel">
	<div id="carouselContainer">
		<?php $n=4; for ($i=0; $i < $n-1; $i++) {echo('<div class="carouselDummy"></div>'); } 
		for ($i=0; $i < $n; $i++) {echo('<div class="carouselImg"></div>'); } ?>
	</div>
</div>
<div id="frontPage">
	<img src="/logo.png">
	<form action="filelist.php" method="get" target="_blank">
		<input type="text" name="q" id="searchBar" maxlength="100">
	</form>
	<div id="dots"> <?php for ($i=0; $i < 4; $i++) {echo('<button id="dot'.$i.'" onclick="dotAct(this)"></button>'); }?> </div>
</div>

<script type="text/javascript">
	var x = document.getElementsByClassName('carouselImg');
	for (var i = x.length-1; i >= 0; i--) {x[i].style.backgroundImage = "url('source/img/wallpaper/img"+i+".jpg')"; }
</script>
<div id="trendingDiv">
	<div id="trendingTitle">Trending this week</div>
	<div id="trendingIconsDiv">
<?php $conn =	new mysqli("103.21.58.5:3306","loremipsum","##@LoremIpsum@##","loremipsum")
	or die("Connection failed: " . $conn->connect_error);
	$result = $conn->query("SELECT idf,ftype,title FROM files ORDER BY mdate DESC LIMIT 4;"); 
	if($result->num_rows>0){while($row = $result->fetch_assoc()){
		echo '<div class="'.$row["ftype"].'" 
		onclick="window.open(\'/file.php?'.base_convert($row["idf"],10,36).'.'.$row["ftype"].'\')">'.$row["title"].'</div>';
	}} $conn->close(); 
?>	</div>
</div>
<div style="text-align:center;">
	<button id="sitemapButton" onclick="window.open('/filelist.php');">See all files</button>
</div>
<div style="height:1em; border-bottom:1px solid #ccc; width:70vw; margin: 1em auto 3em;"></div>
<div id="middlePage">
	<div class="highlightHeading">Our Mission</div>	
	<div>
		<img src="/source/img/sample.png" class="highlightImg" style="float:left; margin: 0 2em 2em 0;">
		<p class="highlightTitle">Vivamus a mi morbi neque</p>
		Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Maecenas porttitor congue massa. Fusce posuere, magna sed pulvinar ultricies, purus lectus malesuada libero, sit amet commodo magna eros quis urna. Nunc viverra imperdiet enim. Fusce est. Vivamus a tellus. Pellentesque habitant morbi tristique.
	</div>

	<div>
		<img src="/source/img/sample.png" class="highlightImg" style="float:right; margin: 0 0 2em 2em;">
		<p class="highlightTitle">Donec ullamcorper</p>
		Fusce aliquet pede non pede. Suspendisse dapibus lorem pellentesque magna. Integer nulla. Donec blandit feugiat ligula. Donec hendrerit, felis et imperdiet euismod, purus ipsum pretium metus, in lacinia nulla nisl eget sapien. Donec ut est in lectus consequat consequat. Etiam eget dui. Aliquam erat volutpat.		
	</div>

	<div>
		<img src="/source/img/sample.png" class="highlightImg" style="float:left; margin: 0 2em 2em 0;">
		<p class="highlightTitle">Purus lectus malesuada</p>
		Maecenas odio dolor, vulputate vel, auctor ac, accumsan id, felis. Pellentesque cursus sagittis felis. Pellentesque porttitor, velit lacinia egestas auctor, diam eros tempus arcu, nec vulputate augue magna vel risus. Cras non magna vel ante adipiscing rhoncus. Vivamus a mi. Morbi neque. Aliquam erat volutpat. Integer ultrices lobortis eros. Pellentesque habitant
	</div>

	<div>
		<img src="/source/img/sample.png" class="highlightImg" style="float:right; margin: 0 0 2em 2em;">
		<p class="highlightTitle">Fusce aliquet pede non pede</p>
		Donec elit est, consectetuer eget, consequat quis, tempus quis, wisi. In in nunc. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos hymenaeos. Donec ullamcorper fringilla eros. Fusce in sapien eu purus dapibus commodo. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Cras faucibus condimentum odio.	
	</div>

</div>
<?php include $root.'/source/common/bodyBottom.php';?>
</body>
<script type="text/javascript">
	document.getElementById('dots').getElementsByTagName('button')[0].click();
	setInterval(function(){
		if (carrPoint==0) {carrDir=0;}
		if (carrPoint==3) {carrDir=1;}
		if(carrDir){document.getElementById('dots').getElementsByTagName('button')[carrPoint].click();carrPoint--;}
		else{document.getElementById('dots').getElementsByTagName('button')[carrPoint].click();carrPoint++;}
	},5000);
</script>
</html>