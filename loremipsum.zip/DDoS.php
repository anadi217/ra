<?php foreach ($_COOKIE as $key => $value) {setcookie($key,false,0,"/");}
?>

<!DOCTYPE html>
<html>
<head>
	<?php include $_SERVER['DOCUMENT_ROOT'].'/source/common/htmlHead.php';?>
	<title>You have been temporarily blocked</title>
	<style type="text/css">
	#a{text-align: center; margin-top: 30vh; font-size: 3.75rem;}
	#b{text-align: center; margin-top: 1rem; font-size: 2rem;}
	</style>
</head>
<body>

	<div id="a">Lorem Ipsum</div>
	<div id="b">You have been banned for <span>30 minutes. Please try again later. </div>

</body>
</html>