if (window.XMLHttpRequest) {xmlhttp = new XMLHttpRequest();} 
else {xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");}

function dateSet(m) {
	var dates="";
	for(var i=1;i<29; i++){dates+="<option value='d"+i+"'>"+i+"</option>";}
	if(m==1){
		if(parseInt(document.getElementById("year").value.slice(1))%4==0){
			dates+="<option value='d29'>29</option>";
		}
	}
	else if(m==3||m==5||m==8||m==10){for(var i=29;i<31; i++){dates+="<option value='d"+i+"'>"+i+"</option>";} }
	else {for(var i=29;i<32; i++){dates+="<option value='d"+i+"'>"+i+"</option>";} }
	document.getElementById('date').innerHTML=dates;
}

var input_height="";
function styleForm() {
	input_height = document.getElementById('form').getElementsByTagName('input')[0].height+4.5;
	var elem_arr = document.getElementById('form').getElementsByClassName('formplaceholder');
	for (var i = elem_arr.length - 1; i >= 0; i--) {
		elem_arr[i].style.marginTop=""+input_height+"px";
	}
}
function holder_up(inp) {
		elem=inp.previousElementSibling;
		elem.style.marginTop="-1rem";
		elem.style.fontSize=".8em";
}
function holder_down(inp) {
	elem=inp.previousElementSibling;
	elem.style.marginTop=""+input_height+"px";
	elem.style.fontSize="1em";
}

function formValidate(elem) {
	switch (elem.id) {
		case "name":
			elem.className=""; 
			q=elem.value.trim();
			var regB=/[^a-zA-Z \d\.']/; var regG=/[a-zA-Z]/;
			if(regB.test(q)||!regG.test(q)){elem.className="wrong";}
			else {if((q).length>5){elem.className="correct";}}
		break;

		case "username":
			elem.className=""; var reg = /^[a-zA-Z][a-zA-Z0-9]*[\._]?[a-zA-Z0-9]+$/;
			if(elem.value!=""&&!reg.test(elem.value)){elem.className="wrong"; }
			else{elem.className="";}
		break;

		case "password":
			var p = document.getElementById('passwordRestrictions').getElementsByClassName('pr');
			var q = String(elem.value);
			var reg1 = /[a-z]/;
			var reg2 = /[A-Z]/;
			var reg3 = /[\d]/;
			var reg4 = /[\@\#\:\.\/\_]/;
			var reg5 = /[^\w\d\@\#\:\.\/]/; //unnecessarily escaped to be sure
			if(q.length<6){p[0].className="pr wrong";} else{p[0].className="pr correct";}
			if(reg1.test(q)){p[1].className="pr correct";} else{p[1].className="pr wrong";}
			if(reg2.test(q)){p[2].className="pr correct";} else{p[2].className="pr wrong";}
			if(reg3.test(q)){p[3].className="pr correct";} else{p[3].className="pr wrong";}
			if(reg4.test(q)&&!reg5.test(q)){p[4].className="pr correct";}
				else{p[4].className="pr wrong";}
		break;

		case "password2":
			if(elem.value!==document.getElementById('password').value){elem.className="wrong";}
			else {elem.className="correct";}
		break;

		case "email":
			var reg = /^\w+[\w\.]*\@[\w\.]+\.\w+$/;
			if(!reg.test(elem.value)){elem.className="wrong";}
			else {elem.className="correct";}
		break;

		case "phone":
			if(String(elem.value).length!=10){elem.className="wrong";}
			else {elem.className="correct";}
		break;

	}

}
function isNumber(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
}
var username_val="";
function usernameValidate(elem){
	if(elem.value!==username_val){
		username_val=elem.value;
		if(username_val.length>5 && elem.className!="wrong"){
			elem.className="loading";
			xmlhttp.onreadystatechange = function() {
				if (this.readyState==4 && this.status==200) {
					var t = this.responseText;
					if(t.toLowerCase().indexOf("error")>-1){console.log(t);}
					else{eval(t);}
				}
			}
			xmlhttp.open("POST","source/checkUsername.php",true);
			xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
			xmlhttp.send("q="+username_val);
		}
		else{elem.className="wrong";}
	}
}
function submitForm() {
	var c_arr=document.getElementById('form').getElementsByClassName('wrong');
	if (c_arr.length===0){return true;}
	else return false;

}