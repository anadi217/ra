<?php
//================[ PRE ]================
if(isset($_POST["pre"])){
	$pre = (int)substr($_POST["pre"],1);
	if($pre===0){$pre=0; $pre_text="Mr.";}
	else if($pre===1){$pre=1; $pre_text="Ms.";}
	else if($pre===2){$pre=10; $pre_text="Dr.";}
	else if($pre===3){$pre=11; $pre_text="";}
	else{exit("error 500");}
} else{exit("error 400");}

//================[ NAME ]================
if(isset($_POST["name"])){
	$name = $_POST["name"];
	if (preg_match("/[^a-zA-Z \d\.']/",$name)||
		!preg_match("/[a-zA-Z]/",$name)||
		strlen($name)<5||
		strlen($name)>64
		){
		exit("error 400");
	}	
} else{exit("error 400");}

//================[ USERNAME ]================
if(isset($_POST["username"])){
	$username = $_POST["username"];
	if (!preg_match("/^[a-zA-Z][a-zA-Z\d]*[\._]?[a-zA-Z\d]+$/",$username)||
		strlen($username)<5||
		strlen($username)>32
		){
		exit("error 400");
	}	
} else{exit("error 400");}

//================[ PASSWORD ]================
if(isset($_POST["password"])){
	$password = $_POST["password"];
	if (
		preg_match("/[^\w\d\@\#\:\.\/]/",$password)||
		!preg_match("/[a-z]/",$password)||
		!preg_match("/[A-Z]/",$password)||
		!preg_match("/[\d]/",$password)||
		!preg_match("/[\@\#\:\.\/\_]/",$password)||
		strlen($password)<5||
		strlen($password)>32
		){
		exit("error 400");
	}	
} else{exit("error 400");}

//================[ EMAIL ]================
if(isset($_POST["email"])){
	$email = $_POST["email"];
	if (!preg_match("/^\w+[\w\.]*\@[\w\.]+\.\w+$/",$email)||
		strlen($email)<5||
		strlen($email)>32
		){
		$email="";
	}	
} else{$email="";}

//================[ BIRTHDAY ]================
if(isset($_POST["year"])){
	$year = "".substr($_POST["year"],1);
	if (preg_match("/[^\d]/",$year)||strlen($year)!=4){
		$year=0;
	}	
} else{$year=0;}

if(isset($_POST["month"])){
	$month = "".((int)substr($_POST["month"],1)+1);
	if (preg_match("/[^\d]/",$month)||(strlen($month)!=2&&strlen($month)!=1)){
		$month=0;
	}	
} else{$month=0;}

if(isset($_POST["date"])){
	$date = "".(int)substr($_POST["date"],1);
	if (preg_match("/[^\d]/",$date)||(strlen($date)!=2&&strlen($date)!=1)){
		$date=0;
	}	
} else{$date=0;}

//================[ COUNTRY ]================
if(isset($_POST["country"])){
	$country = substr($_POST["country"],1);
	if (preg_match("/[^\d]/",$country)){
		$country=(int)$country;
		if($country>=0||$country<233){
			$country=0;
		}
	}	
} else{$country=0;}

//================[ PHONE ]================
if(isset($_POST["phone"])){
	$phone = "".$_POST["phone"];
	if (preg_match("/[^\d]/",$phone)||strlen($phone)!=10){
		$phone=0;
	}	
} else{$phone=0;}

$sql1="INSERT INTO account(pre,name,email,birthday,country,phone) 
	VALUES (b'$pre','$name','$email','$year-$month-$date',$country,'$phone');";
$conn =	new mysqli("103.21.58.5:3306","loremipsum","##@LoremIpsum@##","loremipsum") 
	or die("Connection failed: " . $conn->connect_error);
$conn->query($sql1); $id_n=$conn->insert_id;
$sql2= "INSERT INTO login(id,username,password) VALUES ($id_n,'$username','$password');";
$conn->query($sql2); $conn->close();

setcookie("h_off",0,0, '/');
setcookie("client_name",$name,0, '/');
session_set_cookie_params(0); session_start(); //new account, so invalidate session on browser close
$_SESSION["client_id"]=$id_n;
$_SESSION["client_rank"] = 0;
$_SESSION["client_ida"] = 0; 

header('Location: /i/');
exit(0);
?>
