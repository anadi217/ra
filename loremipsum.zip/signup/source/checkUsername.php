<?php session_start();
if (!isset($_SESSION["blocked"])){include $_SERVER['DOCUMENT_ROOT'].'/source/blacklist/check.php';}
if($_SESSION["blocked"]===true){exit('window.location = "/DDoS.php";'); }

if( !isset($_POST["q"]) ){exit("Error 400. Username not defined.");}else{$q = $_POST["q"];}
if (preg_match("/^[a-zA-Z][a-zA-Z\d]*[\._]?[a-zA-Z\d]+$/",$q) && strlen($q)>5 && strlen($q)<32 ){
	$conn =	new mysqli("103.21.58.5:3306","loremipsum","##@LoremIpsum@##","loremipsum") 
			or die("Error Connection failed: " . $conn->connect_error);
	$result = $conn->query("SELECT id FROM login WHERE username='".$q."';");
	$conn->close(); if($result->num_rows===0){exit('elem.className="correct";');}
}
exit('elem.className="wrong";');
?>