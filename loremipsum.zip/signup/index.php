<?php $root = $_SERVER['DOCUMENT_ROOT']; 
session_start();
if (!isset($_SESSION["blocked"])){include $_SERVER['DOCUMENT_ROOT'].'/source/blacklist/check.php';}
if($_SESSION["blocked"]===true){header("Location: /DDoS.php");exit();}
foreach ($_COOKIE as $key => $value) {setcookie($key,false,0,"/");}
?>
<!DOCTYPE html>
<html>
<head>
	<?php include $root.'/source/common/htmlHead.php';?>
	<title>Signup : Lorem Ipsum</title>
	<link rel="stylesheet" type="text/css" href="source/css.css">
	<script type="text/javascript" src="source/js.js"></script>
	<script type="text/javascript" src="source/countriesArr.js"></script>
</head>
<body>
<?php include $root.'/source/common/bodyTop.php';?>
<div id="signUpTitle" onclick="window.location.reload(true);">Create your Lorem Ipsum Account</div>
<div id="window">
	<div id="window1">
	<form id="form" action="source/submit.php" method="post" onsubmit="return submitForm()" >
	<!-- ~~~~~~~~ NAME ~~~~~~~~ !-->
		<div style="display:flex;flex-flow:row nowrap; align-items: flex-end;">
			<div>
				<select id="pre" name="pre">
					<option value="p0">Mr.</option>
					<option value="p1">Ms.</option>
					<option value="p2">Dr.</option>
					<option value="p3">&nbsp;&ndash;&nbsp;</option>
				</select>&emsp;
			</div>
			<div class="formelem" style="flex-grow: 1;">
				<div class="formplaceholder">Full Name</div>
				<input 
					type="text" required
					autocomplete="off"
					id="name" name="name"
					maxlength="63" 
					onfocus="if(this.value==''){holder_up(this);}" 
					onblur="if(this.value==''){holder_down(this);} 
							if((this.value).length<5){this.className='wrong';}"
					onkeyup="formValidate(this);"
					onchange="if((this.value).length<5){this.className='wrong';}"
				>
			</div>
		</div>

	<!-- ~~~~~~~~ USERNAME ~~~~~~~~ !-->
		<div class="formelem">
			<div class="formplaceholder">Username</div>
			<input 
				type="text" required 
				autocomplete="off"
				id="username" name="username" 
				maxlength="31"
				onfocus="if(this.value==''){holder_up(this);}" 
				onblur="if(this.value==''){holder_down(this);}usernameValidate(this);" 				
				onkeyup="formValidate(this);" 
				onchange="usernameValidate(this);"
			>
			<div id="usernameProblem">Username can contain only letters, numbers, dots or underscore</div>
		</div>

	<!-- ~~~~~~~~ PASSWORD ~~~~~~~~ !-->
		<div class="formelem" style="">
			<div class="formplaceholder">Password</div>
			<input 
				type="password" required
				autocomplete="off"
				id="password" name="password" 
				maxlength="31"
				onfocus="if(this.value==''){holder_up(this);}" 
				onblur="if(this.value==''){holder_down(this);}"
				onchange="" 
				onkeyup="formValidate(this);document.getElementById('password2').value='';"
			>
			<div id="passwordRestrictions">
				<div class="pr">More than 6 characters, less than 32</div>
				<div class="pr">Atleast one lowercase letter (a-z)</div>
				<div class="pr">Atleast one uppercase letter (A-Z)</div>
				<div class="pr">Atleast one number (0-9)</div>
				<div class="pr">Atleast one of these symbols 
					<span style="font-family:monospace; letter-spacing:3px; font-size:1.1em;">@#:./_</span>
				</div>
			</div>
		</div>
		<div class="formelem">
			<div class="formplaceholder">Confirm Password</div>
			<input 
				type="password" required
				autocomplete="off"
				id="password2"
				maxlength="31"
				onfocus="if(this.value==''){holder_up(this);}"  
				onblur="if(this.value==''){holder_down(this);}
				if(this.value!==document.getElementById('password').value){this.className='wrong';}"
				onkeyup="this.className='';" 
				onchange="formValidate(this);"
			>
		</div>

	<!-- ~~~~~~~~ REST ~~~~~~~~ !-->
		<div class="formelem">
			<div class="formplaceholder">Email address</div>
			<input
				type="email"
				autocomplete="off"
				id="email" name="email"
				onfocus="if(this.value==''){holder_up(this);}"  
				onblur="if(this.value==''){holder_down(this);this.className='';}"
				onkeyup="this.className='';" 
				onchange="formValidate(this);"
			>
		</div>
		
		<div class="formelem" style="display:flex; align-items:center; justify-content:flex-start;">
			Birthday&emsp;
			<select 
				id="year" name="year" 
				onchange="dateSet(parseInt(document.getElementById('month').selectedIndex))"
			></select>&ensp;
			<select id="month" name="month" onchange="dateSet(parseInt(this.selectedIndex))"></select>&ensp;
			<select id="date" name="date"></select>
		</div>
		
		<div class="formelem">Country&emsp;
			<select id="country" name="country"></select>
		</div>
		
		<div style="display: flex;flex-flow: row nowrap; align-items: flex-end;">
			<input type="text" tabindex="-1" id="ccallcode" value="+91" readonly size="3">&nbsp;
			<div class="formelem" style="flex-grow: 1;">
				<div class="formplaceholder">Contact number</div>
				<input
					type="text"
					maxlength="10" minlength="10"
					autocomplete="off"
					id="phone" name="phone"
					onfocus="if(this.value.length==0){holder_up(this);}" 
					onblur="if(this.value.length==0){holder_down(this);this.className='';}"
					onkeypress="return isNumber(event)"
					onchange="formValidate(this);"       
				>
			</div>
		</div>

		<div style="text-align:center;margin-bottom: 0;">
			<input type="submit" class="submit" onclick="busy=true;">
		</div>

	</form>
	</div>
	<div id="window2">
		<div class="highlightHeading">Enjoy features of a registered Lorem Ipsum account</div>
		<div class="highlightDiv">
			<img src="img/h1.svg" class="highlightImg">
			<div class="highlightText"><p>Personalized content</p>History, bookmarks, subscriptions, periodicals, personalized suggestions &amp; much more <span style="letter-spacing: 3px">...</span>
			</div>
		</div>
		<div class="highlightDiv">
			<div class="highlightText">
				<div class="highlightText"><p>Commenting</p>Leave a comment on the articles you read, upvote, downvote or respond to others' comments
				</div>
			</div>
			<img src="img/h2.svg" class="highlightImg">
		</div>
		<div class="highlightDiv">
			<img src="img/h3.svg" class="highlightImg">
			<div class="highlightText">
				<div class="highlightText"><p>Dashboard</p>Have a personalized global profile page where  others can see the topics you're interested in, your contributions, comments, bookmars, etc
				</div>
			</div>
		</div>
		<div class="highlightDiv">
			<div class="highlightText">
				<div class="highlightText"><p>Join the community</p>Became a part of this ever growing community and never miss out on any new developments.
				</div>
			</div>
			<img src="img/h4.svg" class="highlightImg">
		</div>
	</div>
</div>
<br>&nbsp;
<?php include $root.'/source/common/bodyBottom.php';?>
</body>
<script type="text/javascript">
	var month_arr=["January","February","March","April","May","June","July","August","September","October","November","December"]; var months = "";
	for (var i = 0; i<12; i++) {months+="<option value='m"+i+"'>"+month_arr[i]+"</option>"; }
	document.getElementById('month').innerHTML=months;
	var years = ""; var dateobj = new Date();
	for (var i = dateobj.getFullYear()-10; i >= 0; i--) {years+="<option value='y"+i+"'>"+i+"</option>"; }
	document.getElementById('year').innerHTML=years;
	dateSet(0);
	var countries=""; for (var i=0; i<countries_arr.length; i++) {
		if(countries_arr[i]=="India"){
			countries+="<option selected value='c"+i+"'>"+countries_arr[i]+"</option>";
		}
		else{countries+="<option value='c"+i+"'>"+countries_arr[i]+"</option>";}
	} document.getElementById('country').innerHTML=countries;
	styleForm();
</script>
</html>