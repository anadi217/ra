var notifStatusN=1;
function notifStatus() { //disables notification
	var s = parseInt(document.getElementById('notification').src.slice(-5,-4));
	if(s==notifStatusN){document.getElementById('notification').src="source/img/notification0.svg";}
	else{document.getElementById('notification').src="source/img/notification"+notifStatusN+".svg";}
	//xmlHTTP request
}
function sidePaneShow() {
	document.getElementById("sidePaneClearanceWindow").style.display="block";
	document.getElementById("sidepane").style.left="0px";
}
function sidePaneClose() {
	document.getElementById("sidepane").style.left="-51ch";
	document.getElementById("sidePaneClearanceWindow").style.display="none";	
}

sidepaneText=""; busy=false;
function sidePaneClick(elem){
	if(sidepaneText!=elem.innerText&&!busy){
		busy=true; sidepaneText=elem.innerText;
		q=sidepaneText.toLowerCase().trim().replace(/\s/g,"_");
		document.getElementById('sidepaneDiv').getElementsByClassName('active')[0].className="";
		elem.className="active"; sidePaneClose();
		document.getElementById('plugFill').src="plugs/"+q+"/php.php";
		busy=false;
	}
}