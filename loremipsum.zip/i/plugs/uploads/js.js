activeArr = new Set();
function activeCheckCall() {
	if(activeArr.size==0){
		var n = document.getElementById('virtualDir').getElementsByTagName('div').length;
		document.getElementById('countDivA').innerHTML=n;
		if (n==1) {document.getElementById('countDivB').innerHTML = "file";}
		else {document.getElementById('countDivB').innerHTML = "files";}
		document.getElementById('countDivC').innerHTML="found";
		document.getElementById('actionButtonsDiv').getElementsByTagName('img')[0].style.display="none";
		document.getElementById('actionButtonsDiv').getElementsByTagName('img')[1].style.display="none";
		document.getElementById('actionButtonsDiv').getElementsByTagName('img')[2].style.display="none";
		document.getElementById('actionButtonsDiv').getElementsByTagName('img')[3].style.display="none";
	}
	else{
		var n = activeArr.size;
		document.getElementById('countDivA').innerHTML=n;
		if (n==1) {document.getElementById('countDivB').innerHTML = "file";}
		else {document.getElementById('countDivB').innerHTML = "files";}
		document.getElementById('countDivC').innerHTML="selected";
		document.getElementById('actionButtonsDiv').getElementsByTagName('img')[0].style.display="block";
		document.getElementById('actionButtonsDiv').getElementsByTagName('img')[1].style.display="block";
		document.getElementById('actionButtonsDiv').getElementsByTagName('img')[2].style.display="block";
		document.getElementById('actionButtonsDiv').getElementsByTagName('img')[3].style.display="block";
	}
}
function uploadFile(elem){
	if(elem.files.length>1||elem.files[0].size>15*1024*1024){ //max: 15 MB
		activeArr.clear(); activeCheckCall();
		alert('file size too large'); elem.value='';
		return false;
	}else{document.getElementById('fileform').submit();}
}

function fclickClear(){
	activeArr.clear(); activeCheckCall();
	var arr = document.getElementById('virtualDir').getElementsByClassName('active');
	for (var i = arr.length - 1; i >= 0; i--) {
		arr[i].className=arr[i].className.replace("active","").trim();
	}
}
function fclick(elem) {	 
	var str = elem.className;
	if(str.search("active")>0){
		elem.className=str.replace("active","").trim();
		activeArr.delete(elem.id);
	}
	else{
		activeArr.add(elem.id);
		elem.className+=" active";
	}
	activeCheckCall();
}

function fileTask(task){
	if(task=="edit"){
		window.open("/features.php?q=editdocs","_blank"); 
	}
	if(task=="view"){
		activeArr.forEach(function(i){
			window.open("/file.php?q="+i,"_blank");
		});
	}
	if(task=="delete"&&confirm("Delete "+activeArr.size+" files?")){
		var q = "";
		activeArr.forEach(function(i){
			document.getElementById(i).remove();
			q += i+",";
		});
		if (window.XMLHttpRequest) {xmlhttp = new XMLHttpRequest();} 
		else {xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");}
		xmlhttp.onreadystatechange = function() {
			if (this.readyState==4 && this.status==200) {
				var t = this.responseText; console.log(t);
				//if(t.toLowerCase().indexOf("error")>-1){
				//	console.log(t); alert("DELETE failed");
				//}			
			}
		}
		//console.log(q);
		xmlhttp.open("POST","/i/plugs/delete.php",true);
		xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
		xmlhttp.send("q="+q.replace(/\,$/,""));	
	}
	if(task=="download"){
		var q = "";
		activeArr.forEach(function(i){q += i+","; });
		window.open("/i/plugs/download.php?q="+q.replace(/\,$/,""),"_blank");		
	}
	fclickClear();
}