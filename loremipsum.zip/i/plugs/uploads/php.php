<?php session_start(); include $_SERVER['DOCUMENT_ROOT'].'/source/common/bCheck.php';

if(!isset($_SESSION["client_id"])|| !isset($_SESSION["client_rank"])||!isset($_SESSION["client_ida"]) ){
	exit("Error 400. Bad Access.");
}if($_SESSION["client_rank"]!=1||$_SESSION["client_ida"]==0){exit("Error 401. Access Denied."); } ?>

<?php include $_SERVER['DOCUMENT_ROOT'].'/source/common/htmlHead.php';?>
<link rel="stylesheet" type="text/css" href="css.css">
<script type="text/javascript" src="js.js"></script>
<div id="uploadHeader">	
	<div id="countDiv" onclick="window.location.reload(true);">
		<span id="countDivA"></span>
		<span id="countDivB"></span>
		<span id="countDivC"></span>
	</div>
	<button id="newfile" onclick='var el=document.getElementById("userfile"); el.value=""; el.click();'>new</button>
</div>
<div id="actionButtonsDiv" onclick="fclickClear();">&nbsp;
	<img src="/i/source/img/view.svg" class="actionButtons" 
		onclick="event.stopPropagation(); fileTask('view');">
	<img src="/i/source/img/download.svg" class="actionButtons" 
		onclick="event.stopPropagation();fileTask('download');">
	<img src="/i/source/img/edit.svg" class="actionButtons" 
		onclick="event.stopPropagation();fileTask('edit');">
	<img src="/i/source/img/delete.svg" class="actionButtons" 
		onclick="event.stopPropagation();fileTask('delete');">
</div>
<div style="display: none;">
	<form  id="fileform" 
		action="/i/plugs/upload1.php" enctype="multipart/form-data" method="POST" target="_blank">
	<input type="hidden" name="MAX_FILE_SIZE" value="15728640">
	<input type="file" name="userfile" id="userfile" onchange="uploadFile(this);">
</div>
<div id="virtualDir" onclick="fclickClear();">
<?php $conn =	new mysqli("103.21.58.5:3306","loremipsum","##@LoremIpsum@##","loremipsum")
	or die("Connection failed: " . $conn->connect_error);
	$result = $conn->query("SELECT idf,ftype,title FROM files WHERE ida=".$_SESSION['client_ida'].";"); 
	if($result->num_rows>0){while($row = $result->fetch_assoc()){
		echo '<div id="'.base_convert($row["idf"],10,36).'.'.$row["ftype"].'" 
		class="'.$row["ftype"].'" onclick="event.stopPropagation();fclick(this)">'.$row["title"].'</div>';
	}} $conn->close(); 
		//echo "<br>id: ".$_SESSION["client_id"];
		//echo "<br>rank ".$_SESSION["client_rank"];
		//echo "<br>ida ".$_SESSION["client_ida"];
?>
</div>
<script type="text/javascript"> 
activeCheckCall();
var h = document.body.clientHeight
	-document.getElementById("uploadHeader").clientHeight
	-document.getElementById("actionButtonsDiv").clientHeight ;
	document.getElementById("virtualDir").style.minHeight= 0.75*h+"px";
</script>
