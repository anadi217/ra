<?php 
$zip = new ZipArchive();
if(!isset($_GET["q"])){exit("Error 400. Bad Access.");}else {$files = explode(",",$_GET["q"]);}
$dir = $_SERVER['DOCUMENT_ROOT']."\\files\\";
foreach ($files as $key => $val) {$files[$key] = $dir.$val; }

# create new zip opbject
$zip = new ZipArchive();

# create a temp file & open it
$zip_file = tempnam('.','');
$zip->open($zip_file, ZipArchive::CREATE);

# loop through each file
foreach($files as $file){
    # download file
    $download_file = file_get_contents($file);
    #add it to the zip
    $zip->addFromString(basename($file),$download_file);
}

# close zip
$zip->close();

# send the file to the browser as a download
header('Content-disposition: attachment; filename=download.zip');
header('Content-type: application/zip');
readfile($zip_file);

?>