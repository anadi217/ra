<?php session_start();
include $_SERVER['DOCUMENT_ROOT'].'/source/common/bCheck.php'; 
if(!isset($_SESSION["client_id"])){exit("Error 400. Bad Access.");}
?>
Bonus++ Feature<br>
Not implemented yet<br>
Click <a href="/features.php" target="_blank">here</a> to know more