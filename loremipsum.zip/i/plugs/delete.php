<?php  session_start(); $root=$_SERVER['DOCUMENT_ROOT']; include $root.'/source/common/bCheck.php';

if(!isset($_SESSION["client_id"])||!isset($_SESSION["client_rank"])||!isset($_SESSION["client_ida"]) ){
	exit("Error 4004. Bad Access.");
}if($_SESSION["client_rank"]!=1||$_SESSION["client_ida"]==0){exit("Error 401. Access Denied."); }

if(!isset($_POST["q"])){exit("Error 400. Bad Access.");}else {$q_arr = explode(",",$_POST["q"]);}



$conn =	new mysqli("103.21.58.5:3306","loremipsum","##@LoremIpsum@##","loremipsum") 
	or exit("Error Connection failed: " . $conn->connect_error);

$sql = "DELETE FROM files WHERE ida=".$_SESSION["client_ida"]." AND (";
foreach ($q_arr as $val) {
	//echo "\n";
	//echo $root."\\files\\".$val;
	//echo "\n";
	//echo base_convert(strtok($val,"."),36,10);
	unlink($root."\\files\\".$val); 
	$sql.="idf=".base_convert(strtok($val,'.'),36,10)." OR ";
}
$sql = rtrim($sql," OR ").");";
//echo $sql;
$conn->query($sql);
$conn->close();

?>