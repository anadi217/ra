<?php session_start();
$root=$_SERVER['DOCUMENT_ROOT'];
include $root.'/source/common/bCheck.php';

if(!isset($_SESSION["client_id"])|| !isset($_SESSION["client_rank"])||!isset($_SESSION["client_ida"]) ){
	exit("Error 400. Bad Access.");
}if($_SESSION["client_rank"]!=1||$_SESSION["client_ida"]==0){exit("Error 401. Access Denied."); }

if(!isset($_FILES['userfile']['size'])){exit("bad routing");}
if($_FILES['userfile']['size']>15*1024*1024){exit("file too big");}

//validate files using $_FILES['userfile']['type'];
//validate if file is really as mentioned by above

$_SESSION["file_tmp_name"]="f".$_SESSION["client_ida"].basename($_FILES['userfile']['name']);
$uploadfile = $root.'\\files\temp\\'.$_SESSION["file_tmp_name"];

if (!move_uploaded_file($_FILES['userfile']['tmp_name'], $uploadfile)) {exit("Connection not secure"); }
echo '<div style="display: none;white-space: pre;">'.print_r($_FILES).'</div>';
?>
<!DOCTYPE html>
<html>
<head>
	<?php include $root.'/source/common/htmlHead.php';?>
	<title>File Upload : Lorem Ipsum</title>
	<style type="text/css">
		body{background-color: #b5d0df;}
		#container{
			height: 85vh; width: 90vw;
			max-width: 100ch;
			margin: 2em auto;
			background-color: #eee;
			display: flex;
			flex-flow: column nowrap;
			padding: 1em; box-sizing: border-box;
			border-radius: 4px;
			box-shadow: 2px 2px 4px rgba(0,0,0,0.3);
		}
		#fileName{
			font-size: 0.9em;
			padding: 16px;
			width: 15ch; border-radius: 2px;	
			overflow: hidden; white-space: nowrap; 
			text-overflow: ellipsis;
			background-color: white;
			box-shadow: 0px 1px 2px rgba(0,0,0,0.1);	
			background-repeat: no-repeat;
			background-position: .5em center;
			background-size: 2em;
			border: 1px solid #eee;
			font-family: sans-serif;
		}
		#a,#b,#c{display: flex; flex-direction: column;}
		#a{flex-grow: 1;}
		#b,#c{flex-grow: 3;}
		p{font-size:1.1em; margin:8px 0;}
		textarea{
			flex-grow: 1; margin: 1px 0;
			font-family: sans-serif; font-size: 1em;
			border: none;
			outline: none;
			border-radius: 2px;
			background-color: #fbfbfb;
		}
		textarea:focus{
			background-color: #fefefe;
		}
		#a>div{text-align: right;font-family: monospace; font-size: 1.25em;}
		#d{
			display: flex;
			flex-flow: row wrap;
			justify-content: space-between;
			align-items: center;
		}
		#submit{
			font-family: 'Lato', sans-serif; 
			border:none; outline: none;	
			padding: .75em 1.75ch;
			border-radius: 4px;
			text-transform: uppercase;
			background-color: #64B5F6;
			color: white;
			font-weight: 900;
			font-size:0.8em;
			cursor: pointer;
			letter-spacing: 1.5px;
			box-shadow: 1px 1px 4px #ccc;
		} #submit:active{box-shadow:none !important; }
	</style>
	<script type="text/javascript">
		<?php echo 'console.log("'.pathinfo($uploadfile, PATHINFO_EXTENSION).'");';	?>
	</script>
</head>
<body>
<?php include $root.'/source/common/bodyTop.php';?>
<form action="upload2.php" method="post">
<div id="container">
	<div id="d">
		<div id="fileName"><?php echo $_FILES['userfile']['name'];?></div>
		<input type="submit" id="submit">
	</div>	
	<div id="a">
		<p>Title:</p> 
		<textarea 
		name="title" required
		onkeyup="document.getElementById('charCount').innerHTML=this.value.length" 
		maxlength="200"></textarea>
		<div><span id="charCount"></span>/200</div>
	</div>
	<div id="b">
		<p>Brief description:</p> 
		<textarea name="description" maxlength="65000"></textarea>
	</div>
	<div id="c">
		<p>Tags for indexing:</p>
		<textarea placeholder="hashtag or comma separated" name="tags" maxlength="65000"></textarea>
	</div>	
</div>
</form>
<br>&nbsp;
<?php include $root.'/source/common/bodyBottom.php';?>
</body>
</html>