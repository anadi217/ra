<?php session_start();
$root=$_SERVER['DOCUMENT_ROOT'];
include $root.'/source/common/bCheck.php';

if(!isset($_SESSION["file_tmp_name"])){exit("Error 400. Bad Access."); }

$old_file = $root.'/files/temp/'.$_SESSION["file_tmp_name"];
if(!file_exists($old_file)){exit("Error 400. Bad Stream.");}
$ext = pathinfo($old_file, PATHINFO_EXTENSION);

function exit2($p){unlink($old_file); exit($p);}

if(!isset($_SESSION["client_id"])|| !isset($_SESSION["client_rank"])||!isset($_SESSION["client_ida"]) ){
	exit2("Error 400. Bad Access.");
}if($_SESSION["client_rank"]!=1||$_SESSION["client_ida"]==0){exit2("Error 401. Access Denied."); }

/*fastest way to prevent SQL injection (my method)
simply replace the first occurence of E and e (most common English letter)
with their unicode value (E is &#69; and e is &#101;)
and remove any possible attemp at SQL comments by removing "/*"
also for integration as HTML replace newline characters (\n) with <br>*/
function fix($value)
{
	$value = str_replace("/*","",$value); //removing all occurences of /*
	$patterns = array('/E/','/e/'); $replacements = array('&#69;','&#101;');
	$value = preg_replace($patterns,$replacements,$value,1); //replace once E and e respectively
	$value = preg_replace('/\n/',"<br>",$value); //replace all newline characters
	return $value;
}

if(!isset($_POST["title"])){exit("Error 400. Title not set!"); }
if(strlen($_POST["title"])>200){exit("Error 400. Bad Access.");} else{$title = fix($_POST["title"]);}
if(strlen($_POST["description"])>65000){exit("Error 400. Bad Access.");} 
	else{$description = fix($_POST["description"]);}
if(strlen($_POST["tags"])>65000){exit("Error 400. Bad Access.");} else{$tags = fix($_POST["tags"]);}

//echo "<br>title: ".$title;
//echo "<br>description: ".$description;
//echo "<br>tags: ".$tags;
//echo "<br>ida: ".$_SESSION['client_ida'];
//echo "<br>ext: ".$ext;
//exit();

$conn =	new mysqli("103.21.58.5:3306","loremipsum","##@LoremIpsum@##","loremipsum") 
	or exit("Error Connection failed: " . $conn->connect_error);
$conn->query("INSERT INTO files (ida,ftype,title,description,tags) 
	VALUES (".$_SESSION['client_ida'].",'$ext','$title','$description','$tags')");

$idf_n = base_convert($conn->insert_id,10,36);
if(!copy($old_file,$root.'\files\\'.$idf_n.".".$ext)){
	exit("Error: File could not be saved permanently. 
		It still exists in the temporary directory. 
		Please contact system administrator.");
} 

if(!unlink($old_file)){
	echo ("File saved successfully; but 
		temp file could not be deleted. 
		Please contact system administrator.");
}
?>
<!DOCTYPE html>
<html>
<head>
	<?php include $root.'/source/common/htmlHead.php';?>
	<title>File Upload Successful: Lorem Ipsum</title>
	<style type="text/css">
		#bodyflex{
			display: flex; height: 80vh; width: 100vw;
			flex-direction: column; align-content: center;
			align-items: center; justify-content: center;
			color: #777;
		}
		div{font-size: 2em;}
		a{
			display: block; text-decoration: none; 
			color: inherit; margin: 1em 0;
			border-bottom: 1px solid #777;
		}
	</style>
</head>
<body>
<div id="bodyflex">
	<div>File upload was successful!</div>
	<a href="/i/">Return to dashboard?</a>
</div>
</body>
</html>
