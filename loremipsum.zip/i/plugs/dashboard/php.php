<?php session_start();
include $_SERVER['DOCUMENT_ROOT'].'/source/common/bCheck.php'; 
if(!isset($_SESSION["client_id"])){exit("Error 400. Bad Access.");}
include $_SERVER['DOCUMENT_ROOT'].'/source/common/htmlHead.php';?>
<!--button onclick="window.location.reload(true);" style="position: absolute; z-index: 100;">Refresh</button!-->

<div style="color:#666;display:flex;align-items:center;justify-content:center;font-size:2em;text-transform:capitalize;margin-right:10px;">
	<img src="/source/img/account.svg" style="height:3em;width:3em; margin:10px;">
	<?php echo $_COOKIE['client_name'];?>
</div>
<div style="text-align:center;font-size:1.75em;color:#666; line-height: 2;">
	Dashboard view<br>
	<span style="font-size:1rem; color: #999;">Tip: Click on the menu button (top-left corner) to access other options</span>
</div>

