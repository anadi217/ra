if (window.XMLHttpRequest) {xmlhttp = new XMLHttpRequest();} 
else {xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");}
function toggleNewbies(q){
	if(q){document.getElementById('newbiesDiv').style.display="block"; }
	else{document.getElementById('newbiesDiv').style.display="none"; }
}
var busy = false;
function acc(elem,b,st){
	elem=elem.parentNode.parentNode; var q=elem.id; var lk = false; var del = true;
	if(!st&&!busy){
		if(b&&window.confirm("Are you sure you want to upgrade this account?")){lk="upgrade.php"; }
		if(!b&&window.confirm("Are you sure you want to cancel this request?")){lk="downgrade.php";}
	}
	if(st&&!busy){
		if(b&&window.confirm("Are you sure you want to suspend this account")){lk="downgrade.php";}
		if(!b&&window.confirm("Are you sure you want to delete this request & all data associated with it?")){lk="delete.php";}
	}
	if(lk.length!=0){
		elem.style.opacity="0.2";
		xmlhttp.onreadystatechange = function() {
			if (this.readyState==4 && this.status==200) {
				busy = false; console.log(this.responseText);
				elem.remove();
			}
		}
		xmlhttp.open("POST",lk,true);
		xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
		xmlhttp.send("q="+q);
	}
}


