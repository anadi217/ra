<?php session_start();
if (!isset($_SESSION["blocked"])){include $_SERVER['DOCUMENT_ROOT'].'/source/blacklist/check.php';}
if($_SESSION["blocked"]===true){exit('window.location = "/DDoS.php";'); }

if (!isset($_SESSION["client_id"])||!isset($_SESSION["client_rank"])||!isset($_SESSION["client_ida"])) {
	exit('window.location = "/login/";'); 
}
if($_SESSION["client_rank"]!=2||$_SESSION["client_ida"]!=0){
	exit('window.location = "/login/";'); 
}

if(!isset($_POST['q'])) {exit("Error 400. Bad gateway");} else{$q=(int)$_POST['q'];}
$conn =	new mysqli("103.21.58.5:3306","loremipsum","##@LoremIpsum@##","loremipsum") 
	or die("Error Connection failed: " . $conn->connect_error);

//delete from login
if ($conn->query("DELETE FROM login WHERE id=".$q.";") !== TRUE) {echo $conn->error; } 
echo "console.log('login deleted');";

//get ida and delete from account
$result = $conn->query("SELECT ida FROM account WHERE id=".$q.";"); 
$row = $result->fetch_assoc(); $ida = $row["ida"];
if ($conn->query("DELETE FROM account WHERE id=".$q.";") !== TRUE) {echo $conn->error; } 
echo "console.log('account deleted');";

//delete files
$result = $conn->query("SELECT idf,ftype FROM files WHERE ida=".$ida.";"); 
if($result->num_rows>0){while($row = $result->fetch_assoc()){
	unlink($_SERVER['DOCUMENT_ROOT']."/files"."/".base_convert($row["idf"],10,36).".".$row["ftype"]);
}}
if ($conn->query("DELETE FROM files WHERE ida=".$ida.";") !== TRUE) {echo $conn->error; } 
echo "console.log('all files deleted');";

$conn->close();
?>