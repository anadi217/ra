<?php session_start();
if (!isset($_SESSION["blocked"])){include $_SERVER['DOCUMENT_ROOT'].'/source/blacklist/check.php';}
if($_SESSION["blocked"]===true){exit('window.location = "/DDoS.php";'); }

if (!isset($_SESSION["client_id"])||!isset($_SESSION["client_rank"])||!isset($_SESSION["client_ida"])) {
	exit('window.location = "/login/";'); 
}
if($_SESSION["client_rank"]!=2||$_SESSION["client_ida"]!=0){
	exit('window.location = "/login/";'); 
}

if(!isset($_POST['q'])) {exit("Error 400. Bad gateway");} else{$q=(int)$_POST['q'];}
$conn =	new mysqli("103.21.58.5:3306","loremipsum","##@LoremIpsum@##","loremipsum") 
			or die("Error Connection failed: " . $conn->connect_error);
$result = $conn->query("SELECT MAX(ida) AS ida FROM account;"); 
$row = $result->fetch_assoc(); $id_n = $row["ida"]+1;
$sql="UPDATE account SET rank=b'1',ida=".$id_n." WHERE id=".$q." AND ida=0;";
if ($conn->query($sql) !== TRUE) {echo $conn->error; }
$conn->close();
?>