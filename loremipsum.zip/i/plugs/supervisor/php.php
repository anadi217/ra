<?php session_start();
include $_SERVER['DOCUMENT_ROOT'].'/source/common/bCheck.php'; 
if(!isset($_SESSION["client_id"])|| !isset($_SESSION["client_rank"])){exit("Error 400. Bad Access.");}
if($_SESSION["client_rank"]!=2){exit("Error 401. Access Denied."); }
$conn =	new mysqli("103.21.58.5:3306","loremipsum","##@LoremIpsum@##","loremipsum") 
	or die("Connection failed: " . $conn->connect_error);
?>
<?php include $_SERVER['DOCUMENT_ROOT'].'/source/common/htmlHead.php';?>
<link rel="stylesheet" type="text/css" href="css.css">
<script type="text/javascript" src="js.js"></script>
<!--button onclick="window.location.reload(true);">Refresh</button!-->
<div style="padding: 1rem;">
<?php $result = $conn->query("SELECT id, name, cdate FROM account WHERE rank=0b11;");
if($result->num_rows>0){
	echo '<input type="checkbox" checked onchange="if(this.checked){document.getElementById(\'newbiesDiv\').style.display=\'block\';}else{document.getElementById(\'newbiesDiv\').style.display=\'none\'; }">
		&nbsp;Display requests?
		<div id="newbiesDiv">';
	while($row = $result->fetch_assoc()){ 
		echo '<div class="row" id='.$row["id"].'>';
			echo '<div><p>'.$row["name"].'</p><span>Member since '.$row["cdate"].'</span></div>';
			echo '<div><img src="/source/img/tick.svg" onclick="acc(this,true,false);">';
			echo '<img src="/source/img/cross.svg" onclick="acc(this,false,false);"></div>';
		echo '</div>';
	}
	echo '</div>';
}
$result = $conn->query("SELECT id, name, cdate FROM account WHERE ida>0;");
if($result->num_rows>0){while($row = $result->fetch_assoc()){ 
	echo '<div class="row" id='.$row["id"].'>';
		echo '<div><p>'.$row["name"].'</p><span>Member since '.$row["cdate"].'</span></div>';
		echo '<div><img src="/source/img/suspend.svg" onclick="acc(this,true,true);">';
		echo '<img src="/source/img/cross.svg" onclick="acc(this,false,true);"></div>';
	echo '</div>';
}}?>
</div>
<?php $conn->close();?>