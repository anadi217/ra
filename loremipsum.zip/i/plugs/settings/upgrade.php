<?php session_start();
$root=$_SERVER['DOCUMENT_ROOT'];
include $root.'/source/common/bCheck.php';
if(!isset($_SESSION["client_id"])|| !isset($_SESSION["client_rank"])){
	exit("Error 400. Bad Access.");
}if($_SESSION["client_rank"]>0){exit("Error 400. Meaningless Request"); }

$conn =	new mysqli("103.21.58.5:3306","loremipsum","##@LoremIpsum@##","loremipsum") 
	or die("Error: Connection failed: " . $conn->connect_error);
$result = $conn->query("UPDATE account SET rank=b'11' WHERE id=".$_SESSION["client_id"].";");
echo $conn->error;
$conn->close();
?>