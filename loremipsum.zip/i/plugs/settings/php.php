<?php session_start();
include $_SERVER['DOCUMENT_ROOT'].'/source/common/bCheck.php'; 
if(!isset($_SESSION["client_id"])){exit("Error 400. Bad Access.");}
$conn =	new mysqli("103.21.58.5:3306","loremipsum","##@LoremIpsum@##","loremipsum") 
	or die("Connection failed: " . $conn->connect_error);
$result = $conn->query("SELECT pre, name, rank, email, birthday, country, phone, cdate, designation 
	FROM account WHERE id=".$_SESSION["client_id"].";");
if($result->num_rows===1){$row = $result->fetch_assoc();}
else{exit("Error 500: Account not found");}
?>
<?php include $_SERVER['DOCUMENT_ROOT'].'/source/common/htmlHead.php';?>
<link rel="stylesheet" type="text/css" href="css.css">
<script type="text/javascript" src="js.js"></script>
<div id="bodyflex">
	<?php if ($row["rank"]==0) {?>
	<div id="upgrade"> <button onclick="upgradeRequest(this);">Become author?</button> </div>
	<?php }?>
	
	<div id="changePhoto" onclick="window.open('/features.php?q=profilephoto');">
		<div>Change Photo</div>
	</div>
<p style="font-size: larger; line-height: 1.25;">
<?php echo "<br>Name: ".$row["name"];?><br>
<?php echo "<br>Email: ".$row["email"];?><br>
<?php echo "<br>Birthday: ".$row["birthday"];?><br>
<?php echo "<br>Country: #".$row["country"];?><br>
<?php echo "<br>Phone: ".$row["phone"];?><br>
<?php echo "<br>Member since: ".$row["cdate"];?><br>
</p>
</div>

<script type="text/javascript"> /*
buildVirtualDir(); 
var h = document.body.clientHeight
	-document.getElementById("uploadHeader").clientHeight
	-document.getElementById("actionButtonsDiv").clientHeight ;
	document.getElementById("virtualDir").style.minHeight= 0.75*h+"px";*/
</script>
