function upgradeRequest(elem) {
	if (window.XMLHttpRequest) {xmlhttp = new XMLHttpRequest();} 
	else {xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");}
	xmlhttp.onreadystatechange = function() {
		if (this.readyState==4 && this.status==200) {
			var t = this.responseText;
			if(t.toLowerCase().indexOf("error")>-1){console.log(t);}
			else{
				console.log(t);
				elem.style.backgroundColor="#eee";
				elem.disabled="true";
				elem.innerHTML="Request Sent";
			}
		}
	}
	xmlhttp.open("GET","/i/plugs/settings/upgrade.php",true);
	xmlhttp.send();	
}