<?php 
$root = $_SERVER['DOCUMENT_ROOT']; include $root.'/source/common/phpHead.php';
if(!isset($_SESSION["client_id"])){header("Location: /login/");exit();}
?>

<!DOCTYPE html>
<html>
<head>
	<?php include $root.'/source/common/htmlHead.php';?>
	<title>Profile : Lorem Ipsum</title>
	<link rel="stylesheet" type="text/css" href="source/css.css">
	<script type="text/javascript" src="source/js.js"></script>
</head>
<body>
<!--button onclick="window.location.reload(true);" style="position: absolute; z-index: 100;">Refresh</button!-->
<div id="bodyflex">
	<div id="header">
		<div style="display: flex; align-items: center;width: 10ch;">
			<img id="leftSidePaneTrigger" src="/source/img/menu.svg" onclick="sidePaneShow();">
		</div>
		<div id="Logocenter" onclick="window.location.href='/';">Lorem Ipsum</div>
		<div style="display: flex; align-items: center;">
			<img id="homeicon" onclick="window.location.href='/';" src="source/img/home.svg">
			<img id="notification" onclick="notifStatus();" src="source/img/notification1.svg">
			<img id="logout" onclick='window.location = "/login/";' src="source/img/logout.svg">
		</div>
	</div>
	<iframe id="plugFill" height="150px"> </iframe>
</div>

<div id="sidePaneClearanceWindow" onclick="sidePaneClose();"></div>
<div id="sidepane">
	<div id="profileMini" onclick="sidePaneClose();">
		<img src="source/img/account_white.svg">
		<div style="margin-right:1ch;">
			<?php $first_name = $_COOKIE['client_name'];
			echo substr($first_name,0,strpos($first_name, " ")); ?>
		</div>
	</div>
	<div id="sidepaneDiv">
		<div onclick="sidePaneClick(this);" class="active">
				<img src="source/img/dashboard.svg">Dashboard
		</div>
		<?php if($_SESSION["client_rank"]==1){
			echo '<div onclick="sidePaneClick(this);"><img src="source/img/uploads.svg">Uploads</div>';
		}else if($_SESSION["client_rank"]==2){
			echo '<div onclick="sidePaneClick(this);"><img src="source/img/supervisor.svg">Supervisor</div>';
		} ?>
		<div onclick="sidePaneClick(this);"><img src="source/img/globe.svg">Global Profile</div>
		<div onclick="sidePaneClick(this);"><img src="source/img/bookmarks.svg">Bookmarks</div>
		<div onclick="sidePaneClick(this);"><img src="source/img/read_later.svg">Read later</div>
		<div onclick="sidePaneClick(this);"><img src="source/img/history.svg">History</div>
		<div onclick="sidePaneClick(this);"><img src="source/img/notification_static.svg">Notifications</div>
		<div onclick="sidePaneClick(this);"><img src="source/img/settings.svg">Settings</div>
	</div>
	<img id="sidePaneFooter" src="source/img/logout.svg">
</div>
<br><br>
<?php include $root.'/source/common/bodyBottom.php';?>
</body>
<script type="text/javascript">
	document.getElementById('sidepaneDiv').getElementsByTagName('div')[0].click();
</script>
</html>