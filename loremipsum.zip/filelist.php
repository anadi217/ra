<?php 
if(!isset($_GET['q'])){
	$sql = "SELECT idf,ftype,title FROM files ORDER BY ftype ASC;";
}
else{
	$q = fix($_GET['q']); 
	$sql = "SELECT idf,ftype,title FROM files WHERE title LIKE '%".$q."%'  ORDER BY ftype ASC;";
}

function fix($value)
{
	$value = str_replace("/*","",$value); //removing all occurences of /*
	$value = str_replace("%","",$value); //removing all occurences of %
	$patterns = array('/E/','/e/'); $replacements = array('&#69;','&#101;');
	$value = preg_replace($patterns,$replacements,$value,1); //replace once E and e respectively
	$value = preg_replace('/\n/',"<br>",$value); //replace all newline characters
	return $value;
}

$root = $_SERVER['DOCUMENT_ROOT'];
include $root.'/source/common/phpHead.php';
?>
<!DOCTYPE html>
<html>
<head>
	<?php include $root.'/source/common/htmlHead.php';?>
	<title>All Files | Lorem Ipsum</title>
</head>
<style type="text/css">
.topRightButton{fill: #aaa !important;}
#viewbox{
	display: flex; flex-flow: row wrap;
	align-content: flex-start;
	justify-content: flex-start;
	font-family: 'Lato', sans-serif;
	font-size: .95em; min-height: 90vh;
	padding: 1em;
}
#viewbox>div{
	margin: 1ch; cursor: pointer;
	background-color: #eee;
	padding: 16px 16px 16px 4em;
	width: 15ch; border-radius: 2px;	
	overflow: hidden; white-space: nowrap; text-overflow: ellipsis;
	background-repeat: no-repeat;
	background-position: .5em center;
	background-size: 2em;
	text-transform: capitalize;
	font-family: sans-serif;
	height: 1.2em;
}
.txt,.doc,.docx{background-image: url("/source/img/files/document.svg");}
.html{background-image: url("/source/img/files/html.svg");}
.mp3{background-image: url("/source/img/files/music.svg");}
.pdf{background-image: url("/source/img/files/pdf.svg");}
.png{background-image: url("/source/img/files/photo.svg");}
.xlsx{background-image: url("/source/img/files/spreadsheet.svg");}
.mp4{background-image: url("/source/img/files/video.svg");}

#header{
	padding: 10px 0; font-size: 3em;
	font-family: 'Lato',sans-serif;
	text-align: center; color: #666;
	margin-bottom: 20px;
}
</style>
<body>
<?php include $root.'/source/common/bodyTop.php';?>
<div id="header">
	<a href="/" style="color: inherit; text-decoration: none;">Lorem Ipsum</a><br>
	<span style="font-size:smaller">File Directory</span>
</div>
<div id="viewbox">
<?php $conn =	new mysqli("103.21.58.5:3306","loremipsum","##@LoremIpsum@##","loremipsum")
	or die("Connection failed: " . $conn->connect_error);
	$result = $conn->query($sql); 
	if($result->num_rows>0){while($row = $result->fetch_assoc()){
		echo '<div class="'.$row["ftype"].'" 
		onclick="window.open(\'/file.php?'.base_convert($row["idf"],10,36).'.'.$row["ftype"].'\')">'.$row["title"].'</div>';
	}} $conn->close(); 
?>
</div>
<?php include $root.'/source/common/bodyBottom.php';?>
</div>
</body>
</html>