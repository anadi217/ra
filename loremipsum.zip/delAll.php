<?php session_start();session_unset();session_destroy();
foreach ($_COOKIE as $key => $value) {setcookie($key,false,0,"/");}
?>