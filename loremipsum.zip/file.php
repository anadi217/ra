<?php $root = $_SERVER['DOCUMENT_ROOT'];
if(!isset($_GET["q"])){header("Location: /");exit();} else{$q=$_GET["q"];}
if(preg_match("/[^a-zA-Z\d\.]/",$q)){header("Location: /");exit();}
$q_arr=explode(".",$q);

$q_arr[0]=base_convert($q_arr[0],36,10);
$conn =	new mysqli("103.21.58.5:3306","loremipsum","##@LoremIpsum@##","loremipsum") 
	or exit("Error Connection failed: " . $conn->connect_error);

$result = $conn->query("SELECT * FROM files WHERE idf=".$q_arr[0].";");
if($result->num_rows!==1){exit("Error 500. Multiple files");}
$row = $result->fetch_assoc();

$result = $conn->query("SELECT name FROM account WHERE ida=".$row["ida"].";");
if($result->num_rows!==1){exit("Error 500. Multiple authors");}
$row2 = $result->fetch_assoc();

$conn->close();
include $root.'/source/common/phpHead.php';
?> 
<!DOCTYPE html>
<html>
<head>
	<?php include $root.'/source/common/htmlHead.php';?>
	<title>File: Lorem ipsum</title>
	<link rel="stylesheet" type="text/css" href="source/css.css">
	<script type="text/javascript" src="source/js.js"></script>
</head>
<style type="text/css">
#header{
	padding: 10px 0;
	font-family: 'Lato',sans-serif;
	text-align: center; color: #666;
	margin-top: 10px; text-align: center;
	padding-bottom: 2em;
}
#header>a{
	display: block; color: inherit; 
	text-decoration: none; font-size: 3em; 
	margin-bottom: 10px;
}
#description{
	font-size: 1.1em; line-height: 1.5;
	margin:0.5em; width: 50%;
	margin: auto; max-height: 4.5em;
	overflow: hidden; text-overflow: ellipsis;
}
#header>span{
	font-size: 0.7em; text-transform: uppercase; 
	font-weight:bold;color: #64B5F6;
	cursor: pointer; margin-top: 5px;
}
#header>div{
	width: 40%; margin:.5em auto;
	text-align: right; font-size: 1.1em;
}
#header>div>span{
	font-family: monospace;
	opacity: 0.8;
}
#tagsDiv{
	text-align: center;font-size:smaller; 
	width: 60%; margin:1em auto;
	display: none;
}
</style>
<body>
<!--button onclick="window.location.reload(true);" style="position: absolute; z-index: 100;">Refresh</button!-->
<?php include $root.'/source/common/bodyTop.php';?>
<div id="header">
	<a>Lorem Ipsum</a>
	<p style="font-size: 2em; margin:0.5em;"><?php echo $row["title"];?></p>
	<p id="description"><?php echo $row["description"];?></p>
	<span onclick="document.getElementById('description').style.maxHeight='auto';this.style.display='none'">
	Full description</span>
	<div>&mdash;&emsp;<?php echo $row2['name'];?><br><span><?php echo $row["mdate"];?></span></div>
</div>
<?php
$q_arr[1] = strtolower($q_arr[1]);
if($q_arr[1]=="mp4"||$q_arr[1]=="3gp"||$q_arr[1]=="ogv"||$q_arr[1]=="webm"|| 
	$q_arr[1]=="mp3"||$q_arr[1]=="flac"||$q_arr[1]=="ogg"||$q_arr[1]=="wav"){
echo '<object data=http://loremipsum.redexpresskolkata.com/files/'.$q.' style ="width:100vw; margin:1em auto;min-height:50vh;"> 
    	<embed src=http://loremipsum.redexpresskolkata.com/files/'.$q.' style ="width:100vw; margin:1em auto;min-height:50vh;"> </embed>
    		Error: The page could not be embedded.
		</object>';
}
else{echo "<iframe src='https://docs.google.com/viewer?url=http://loremipsum.redexpresskolkata.com/files/".$q."&embedded=true' frameborder='0' style='width:100vw; margin:1em auto;min-height:100vh;'></iframe>";}?>

<div style="text-align:center;font-weight:bold;color: #64B5F6; cursor: pointer;margin: 5px; font-size: 0.9em;" onclick="document.getElementById('tagsDiv').style.display='block';">SHOW TAGS</div>
<div id="tagsDiv"> 
<?php $tags = preg_replace ('/\s*,\s*/'," #",$row["tags"]); $tags = preg_replace ('/\s*#\s*#\s*/'," #",$tags); echo $tags;?>
</div>

<?php include $root.'/source/common/bodyBottom.php';?>
</body>
</html>






