<!DOCTYPE html>
<html>
<head>
	<?php include $_SERVER['DOCUMENT_ROOT'].'/source/common/htmlHead.php';?>
	<title>Lorem ipsum dolor sit amet</title>
	<link rel="stylesheet" type="text/css" href="source/features.css">
</head>
<body>
	<?php include $_SERVER['DOCUMENT_ROOT'].'/source/common/bodyTop.php';?>
	<div style="background-color: #eee; width: 100vw; padding-bottom: 3em;">
		<div id="header"> Features page for this website </div>
		<div id="container0">
			<div onclick="setup(1,1);">
				<img src="/source/img/basicFeatures.svg">
				<p>Base Website</p>
				<span>&#8377;8,000</span>
				<div>(as decided previously)</div>
				<a>Click for more info</a>
			</div>
			<div onclick="setup(1,2);">
				<img src="/source/img/bonusFeatures.svg">
				<p>Bonus Features</p>
				<span>&#8377;4,000</span>
				<div>(as decided previously)</div>
				<a>Click for more info</a>
			</div>
			<div onclick="setup(1,3);">
				<img src="/source/img/bonusppFeatures.svg">
				<p>Bonus++ Features</p>
				<a>Click for more info</a>
			</div>
		</div>
	</div>
	<br>
	<div class="mainBlock">
		<div class="mHeading">BASE FEATURES</div>
		<div class="mTitle" style="padding: 10px 0;">General Structure of website</div>
		<table id="mT1" width="100%">
			<tr><td>Home page shows catalogue of files/documents/media</td></tr>
			<tr><td>Viewers can create new accounts, securely login and logout</td></tr>
			<tr><td>They can request to be upgraded to author status from "settings"</td></tr>
			<tr><td>Authors can upload files in almost any popular document/multimedia format</td></tr>
			<tr><td>Admins can review "upgrade requests" and suspend/delete existing authors</td></tr>
			<tr><td>Dedicate file page (with unique short GET URLs for bookmarks) capable of showing the file uploaded by the author</td></tr>
			<tr><td>Mobile support for modern browsers</td></tr>
		</table>

		<br>
		<div class="mTitle">Seamless AJAX support</div>
		<div class="mText">
			<span style="font-weight:bold">Making a website is easy. Making a website that people want to visit again is the true challenge.</span><br>
			Having a user’s webpage refresh every time to communicate with the server causes &ndash;
			<table id="mT2">
				<tr><td>Buffer time to fetch resources and parse the webpage again</td></tr>
				<tr><td>Unnecessary traffic and server load, which (for high-end servers) can end up being costly</td></tr>
				<tr><td>The viewer to get irritated and subsequent loss of web-traffic, which is always undesirable</td></tr>
			</table>
			So, as you will notice, the entire complicated website that you see here, effectively has <span style="font-weight:bold">just 5 main pages</span>: homepage, login, signup, dashboard &amp; file-viewer ... and the <span style="font-weight:bold">rest is completely </span>handled using multiple, simultaneous <span style="font-weight:bold">fast AJAX handle and requests</span>
		</div>

		<br>
		<div class="mTitle">Material Design &amp; Icons (SVG)</div>
		<div class="mText">
			The website adheres to the <span style="font-weight:bold">Material UI design and Flat UI design standards</span>, laid out by Google, to give your viewers a touch of familiarity and comfort – making them want to visit the site again<br>
			Additionally, the website uses <span style="font-weight:bold">vector SVG icons</span>, which weigh around <span style="font-weight:bold">100-200 bytes</span>, and can be scaled to fit any size with <span style="font-weight:bold">lossless resolution</span> – thus, making the website faster and the images perfect.
		</div>
		<br> <br> <br>
		<div class="mHeading"><img src="/source/img/bonusFeatures.svg" style="height: 1.25em; width: 1.25em;"><br> BONUS FEATURES </div>

		<div class="mTitle">Size, Speed &amp; Compression</div>
		<div class="mText">
			<img src="/source/img/features/speed.svg" style="float: left; margin:5px 3ch 5px 0; height: 5em; width: 5em;">
			The entire website was made using HTML, CSS, PHP, and native JavaScript.<br>
			<span style="font-weight:bold">NO PLUGINS were used in the website, making it much smaller, extremely fast</span> (relative to server speed) <span style="font-weight:bold">and more secure.</span><br>
			The entire website (sum of all pages, so far) is <span style="font-weight:bold">730 KB uncompressed</span>. On minifying and compressing, it can reduce down to <span style="font-weight:bold; text-decoration: underline;">less than 300KB</span> (size of the entire website)<br>
			To put that in perspective: jQuery plugin is 84 KB, Bootstrap plugin is 360 KB (more than our complete minified website).<br>
			So, by eliminating plugins, the website size and load time have reduced incredibly, giving users a faster, highly responsive UI.<br>
			<span style="font-size: 1rem;">
				Note 1: I am aware that plugins need to be loaded only once and can be reused by other websites; but they still have an impact on effective parse time. So, if they can be avoided, I always choose to do so. <br>
				Note 2: For viewing documents, we are using Google Document Viewer; and for Video player we are using object and native embed tag (for backup)
			</span>
		</div> <br>

		<div class="mTitle">Front-end &amp; Back-end security + Latest language specifications</div>
		<div class="mText">
			<img src="/source/img/features/shield.png" style="float: left; margin:5px 3ch 5px 0; height: 5em; width: 5em;">
			To protect database and files, any information entered by the user is validated <span style="font-weight:bold">on the client-end</span> (for immediate responses) <span style="font-weight:bold">and also on the server-end</span> (to prevent “Inspect Element” bypass) giving the website a <span style="font-weight:bold; text-decoration: underline;">multi-level security check</span> on all data entered<br>
			Additionally, all tags used are as per the latest HTML 5 specifications and do not include any outdated definitions. Same applies for CSS, Javascript and PHP, securing your website for future browser versions
		</div> <br>


		<div class="mTitle">Optimized database + SQL injection safe</div>
		<div class="mText">
			<img src="/source/img/features/injection.png" style="float: left; margin:5px 3ch 5px 0; height: 5em; width: 5em;">
			The entire database is split into 3 tables (login, account and file management) to <span style="font-weight:bold">reduce effective server load</span> and are optimized using the smallest data sizes applicable (including bit size for Boolean content) for <span style="font-weight:bold">high speed processing and data delivery</span>.<br>
			Also, the website is <span style="font-weight:bold">protected against SQL injection attacks</span> (SQL injections occur when the website prompts the user to enter some data like name, email …  but the user instead enters an SQL statement to corrupt the database). Proper steps are taken to ensure SQL injections are rejected
		</div> <br>


		<div class="mTitle">No need for mobile website + Cross platform support</div>
		<div class="mText">
			<img src="/source/img/features/platform.png" style="float: left; margin:5px 3ch 5px 0; height:8em;">
			Using fluid CSS practices, <span style="font-weight:bold">the website runs seamlessly across all touchscreen mobile and desktop screen sizes</span> eliminating the need to even build a mobile website (for all modern browsers)<br>
			For older browsers (desktop and mobile), a separate website with minimal CSS and JS can be built. For more info, see Bonus++ feature
		</div> <br>


		<div class="mTitle">Auto login feature for return viewers</div>
		<div class="mText">
			There is nothing more annoying than to have returning users sign in everytime to access the components of the website. Although, you may not have had the chance to use the auto-login feature, but the <span style="font-weight:bold">“remember me” option</span> is 100% functional.
		</div> <br>


		<div class="mTitle">Carousel w/ controls &amp; position markers</div>
		<div class="mText">
			To display top headline images, the home page is embedded with a responsive, two way, animated, automated and controllable carousel, along with animated position markers – all made without any plugins, but instead pure JavaScript
		</div> <br>



		<div class="mTitle">Contact us Page</div>
		<div class="mText">Contains your details along with a side-by-side interactive frame of <span style="font-weight:bold">Google maps</span> pointing (presently to DTU), but can be redirected to point to your office headquarters or similar
		</div> <br>


		<div class="mTitle">DDoS Attack Protection (Soft)</div>
		<img src="/source/img/features/ddos.png" style="float: left; margin:5px 3ch 5px 0; height:7em; width: 7em;">
		<div class="mText"><span style="font-weight:bold">Distributed Denial of Service (DDoS)</span> occurs when competitors or enemies of the website overload the server with superfluous requests causing legitimate requests from being fulfilled. Analogy: Imagine a group of people unnecessarily crowding at the door, and not letting important people to enter.<br>
			The worst part about it? It does NOT take experienced hackers to write a script to overload the server with “get” and “post” requests or even write a script to guess a username and password.<br>
			Some high-cost servers do provide DDoS protection services, but ultimately, it’s the duty of the website owner to ensure the security of the visitors.<br>
			So far, I have provided “soft” security against multiple login attempts – <span style="font-weight:bold">a sessional object to keep track of DDoS attempts</span> and block the client for malicious activity. <br>
			But the sessional object gets deleted on browser close. This provides only one layer of security, preventing low to medium level automated scripts from succeeding. But, <span style="font-weight:bold">permanent measures must be taken</span> to permanently blacklist individual IP address or an entire IP range. For this, <span style="font-weight:bold">see Bonus++ feature.</span>
		</div>
		<br> <br> <br>

		<div class="mHeading">
			<img src="/source/img/bonusppFeatures.svg" style="height: 2em; width: 2em;"><br>
			BONUS++ FEATURES
		</div>
		<div style="text-align: center; color: #666; line-height: 1.5;">
			In order of commercial importance. Click each to expand for further info
		</div>

		<div class="bppBlock">
			<div class="bRow" onclick="this.classList.toggle('bRowA');">
				<div class="bTitle">Sitemap</div>		
				<div class="bCost">&#8377; 1,500</div>	
			</div>
			<div class="bText">
				Most search engines index web-pages based on the website sitemap.<br>Think of sitemap as the index page to a book – a book that you want Google, Yahoo, Bing.. etc to read.<br>Assuming you want your website to be in somebody’s search list, a sitemap has to be made and submitted to these search engines for indexing
			</div>
		</div>

		<div class="bppBlock">
			<div class="bRow" onclick="this.classList.toggle('bRowA');">
				<div class="bTitle">Security Package 1: DDoS + Database</div>		
				<div class="bCost">&#8377; 9,000</div>	
			</div>
			<div class="bText">
				<p>Localized DDoS attacks: would involve permanently blacklisting individual/range of IPs</p>
				<p><span style="font-weight: bold;">1. Database encryption:</span> Right now, the database is un-encrypted. So, all that a hacker has to do to gain access to thousands of usernames, passwords etc is to DDoS guess the database’s access username &amp; password. After encryption, even if the database is breached, all account’s username and passwords will be secure. Unencrypted database was the major failure behind Yahoo’s 500 Million account leak in 2014.</p>
				<p><span style="font-weight: bold;">2. Application-layer floods:</span> DDoS designed to force the file buffer to overflow. A must for your website.</p>
				<p><span style="font-weight: bold;">3. Degradation-of-service:</span> harder to detect, because they only aim to make a website slow</p>
			</div>
		</div>

		<div class="bppBlock">
			<div class="bRow" onclick="this.classList.toggle('bRowA');">
				<div class="bTitle">Security Package 2: DDoS II</div>		
				<div class="bCost">&ndash;</div>	
			</div>
			<div class="bText">
				<p>Involves dealing with non-localized DDoS attacks – harder to detect because of distributed IP</p>
				<p><span style="font-weight: bold;">1. Distributed DDoS:</span> Infected “zombie” computer attack from malicious software</p>
				<p><span style="font-weight: bold;">2. P2P (highly distributed):</span> ‘zombify’ devices using P2P software (eg: utorrent) for DDoS</p>
				<p><span style="font-weight: bold;">3. DDoS Level 2:</span> make the server falsely believe it’s being attacked &amp; shut down (autoimmune disease)</p>
			</div>
		</div>

		<div class="bppBlock">
			<div class="bRow" onclick="this.classList.toggle('bRowA');">
				<div class="bTitle">Security Package 3: Ping Attacks</div>		
				<div class="bCost">&ndash;</div>	
			</div>
			<div class="bText">
				<p><span style="font-weight: bold;">1. Ping flood:</span> send an overwhelming number of ping packets (very simple to do, very hard to protect)</p>
				<p><span style="font-weight: bold;">2. Black Nurse:</span> popular subtype of above, sends Destination Port Unreachable ICMP packets</p>
				<p><span style="font-weight: bold;">3. Ping of death:</span> Highly specific malformed ping packet designed to cause system crash</p>
			</div>
		</div>


		<div class="bppBlock">
			<div class="bRow" onclick="this.classList.toggle('bRowA');">
				<div class="bTitle">Security Package 4: Server-level Built-in Security Flaws</div>		
				<div class="bCost">&ndash;</div>	
			</div>
			<div class="bText">
				<p><span style="font-weight: bold;">1. Permanent Death:</span> (most dangerous) streamlined DDoS attack targeted only at hardware, aimed to seek and destroy. Can cost huge loss in damages.</p>
				<p><span style="font-weight: bold;">2. R-U-Dead-Yet? (RUDY):</span> correct form submissions, but at very slow rate to occupy submission handles for long time causing server overload</p>
				<p><span style="font-weight: bold;">3. Smurf Reflect attack:</span> send broadcast under your name to a large number of devices, so when all the devices try to call you back regarding the broadcast, your system crashes</p>
			</div>
		</div>

		<div class="bppBlock">
			<div class="bRow" onclick="this.classList.toggle('bRowA');">
				<div class="bTitle">Security Package 5: TCP Security</div>		
				<div class="bCost">&ndash;</div>	
			</div>
			<div class="bText">
				<p><span style="font-weight: bold;">1. Shrew attack:</span> DDoS attack to the TCP (not website), can cause website to start rejecting legitimate requests by considering those to be DDoS attacks</p>
				<p><span style="font-weight: bold;">2. SYN flood:</span> saturates TCP connection with false/forged requests. (Imagine someone standing to your left, reaching their arm around you and patting you on the right shoulder, so you turn to your right to see but no one is there – the request comes from a location where no one is there.)</p>
				<p><span style="font-weight: bold;">3. Teardrop attacks:</span> disfigured IP fragments with overlapping and oversized payloads. Causes system failure as most systems are not designed to check IP fragments before processing</p>
			</div>
		</div>

		<div class="bppBlock">
			<div class="bRow" onclick="this.classList.toggle('bRowA');">
				<div class="bTitle">Notes about Security packages - Read me</div>		
				<div class="bCost">&nbsp;</div>	
			</div>
			<div class="bText">
				<p><span style="font-weight: bold;">Note 1: Do I need all?</span> No. Unless a trained individual or an organization is out to get you, you will be fine. So, select the packages that you find affordable and likely. That being said, also know that all of these attacks can be carried out very easily so if you plan to have a <span style="text-decoration: underline;"> payment portal</span> in your website, it is advised to choose ALL of these packages.</p>
				<p><span style="font-weight: bold;">Note 2: Can you handle it?</span> I will be able to handle all security packages 1-4. Security package 5 is harder to implement because of the way TCP/IP is dealt with at server level, but I have a friend who will handle it. Also, please note that it will take time to implement all these packages.</p>
				<p><span style="font-weight: bold;">Note 3: Why so expensive?</span> </p>
				- some of these attacks can be avoided by choosing a premium cloud/server provider. They will charge you quite a lot too – more than I am; but their payment services will be spread out monthly or annually, while mine are straightway. Also, regarding expensive servers see “<span style="text-decoration: underline;">Compression &amp; Conversion</span>” paragraph one topic below <br>
				- you are definitely encouraged to consult third parties to compare pricing. <br>
				- the “soft protect” I included in bonus, is simply a fast PHP statement called at every page. Since there are just 5 main pages, it’s easy to handle. But the rest cannot be called this way – even modifying web.config (or .htaccess for linux servers) will not be enough. Dedicated scripts are required to be running at server level.</p>
			</div>
		</div>

		<div class="bppBlock">
			<div class="bRow" onclick="this.classList.toggle('bRowA');">
				<div class="bTitle">File upload Virus/Trojan security - <span style="font-weight: bold;">important</span></div>		
				<div class="bCost">&#8377; 3,500</div>	
			</div>
			<div class="bText">
				Your website involves <span style="font-weight: bold;">users uploading files constantly</span>. Even if the “author” account is only rewarded to those trusted by the admin – <span style="font-weight: bold;">unchecked file upload is still a massive security risk.</span><br>
				To the untrained eye, the solution simply is to check for the file extension – but, <span style="font-weight: bold;">malicious code can easily be wrapped up in documents or multimedia</span> and measures must be taken to ensure that any file uploaded, after it clears the DDoS check, is further parsed at the server before storage.<br>
			</div>
		</div>

		<div class="bppBlock">
			<div class="bRow" onclick="this.classList.toggle('bRowA');">
				<div class="bTitle">Compression &amp; Conversion - <span style="font-weight: bold;">important</span></div>		
				<div class="bCost">&#8377; 3,500</div>	
			</div>
			<div class="bText">
				In every <span style="font-weight: bold;">expensive server</span>, there is <span style="font-weight: bold;">surplus billing based on the data transferred between client and server</span>. The website I have designed, with a total of 300KB in size, will not even cut the minimum required for surplus billing. But the website deals extensively with files. Let me illustrate:<br>
				<p>A 322&times;480px JPEG of The Monalisa is 40 KB in size and is enough for browser viewing.<br>
				But the "author" may not care about data conservation, so he/she uploads the picture at 7k&times;11k resoluion which is 90 MB in size.<br>
				<p style="font-weight:bold;">Difference is over 2000 times &mdash; and this will be reflected in your server cost!</p>
				Also, if the user uploads any file in an unsupported format, the browser will not even load the image, but the file will continue to take up server space.</p>

			</div>
		</div>

		<div class="bppBlock">
			<div class="bRow" onclick="this.classList.toggle('bRowA');">
				<div class="bTitle">Legal info, Terms, Policies &amp; Copyright</div>		
				<div class="bCost">&#8377; 1000</div>	
			</div>
			<div class="bText">
				As you will find at the bottom of the page, is a row of hyperlinks: About, Terms of Use, Privacy Policy, Copyright, Certificates. These are supposed to be made by the company’s representatives as a text file or HTML file. But if the company does not have something for this I could make a standard Terms, Policies and About page (after you give me some details)
			</div>
		</div>

		<div class="bppBlock">
			<div class="bRow" onclick="this.classList.toggle('bRowA');">
				<div class="bTitle">No JavaScript, low CSS for old browsers</div>		
				<div class="bCost">&#8377; 2000</div>	
			</div>
			<div class="bText">
				As mentioned before, the website is platform independent and runs smoothly on all modern browsers – making up roughly 85% of the population. But if your target demographic can involve those with ancient browsers or those that have browsers with Javascript disabled by default (eg. Internet Explorer) – a simple CSS, no Javascript, HTML only website can be provided. The original website will have a script to automatically redirect users to this site if they match any of the aforementioned conditions
			</div>
		</div>

		<div class="bppBlock">
			<div class="bRow" onclick="this.classList.toggle('bRowA');">
				<div class="bTitle">Dedicated mobile/desktop apps</div>		
				<div class="bCost">&#8377; 2000</div>	
			</div>
			<div class="bText">
				Android, Linux, Chrome desktop, Chrome OS, Windows mobile, Windows desktop, iOS mobile, iOS desktop
			</div>
		</div>



		<div style="text-align: center; font-size:2em; color: #666;">More Options</div><br>
		<div style="width: 90%; margin: auto;">
			<div class="bRow2">
				<div class="bTitle">Comments Portal</div>
				<div class="bCost">&#8377; 5000</div>	
			</div>
			<div class="bRow2">
				<div class="bTitle">Profile photo for all users</div>
				<div class="bCost">&#8377; 2500</div>	
			</div>
			<div class="bRow2">
				<div class="bTitle">Google, Facebook integration</div>
				<div class="bCost">&#8377; 1000</div>	
			</div>
			<div class="bRow2">
				<div class="bTitle">Global Profile</div>
				<div class="bCost">&#8377; 2500</div>	
			</div>
			<div class="bRow2">
				<div class="bTitle">Bookmarks, Reading list, History</div>
				<div class="bCost">&#8377; 2500</div>	
			</div>
			<div class="bRow2">
				<div class="bTitle">Email confirmation for registration </div>
				<div class="bCost">&#8377; 2000</div>	
			</div>
			<div class="bRow2">
				<div class="bTitle">Password Reset (w/ verification)</div>
				<div class="bCost">&#8377; 1500</div>	
			</div>
			<div class="bRow2">
				<div class="bTitle">Alternative login (via phone, email)</div>
				<div class="bCost">&#8377; 1500</div>	
			</div>
			<div class="bRow2">
				<div class="bTitle">Change Profile Info</div>
				<div class="bCost">&#8377; 1500</div>	
			</div>
			<div class="bRow2">
				<div class="bTitle">Change Dashboard/Login Wallpaper</div>
				<div class="bCost">&#8377; 1500</div>	
			</div>
			<div class="bRow2">
				<div class="bTitle">username already taken < suggestions</div>
				<div class="bCost">&#8377; 2000</div>	
			</div>
			<div class="bRow2">
				<div class="bTitle">Predictive Text for search</div>
				<div class="bCost">&#8377; 3000</div>	
			</div>
			<div class="bRow2">
				<div class="bTitle">Country auto-detect / Precise Location detect</div>
				<div class="bCost">&#8377; 2000</div>	
			</div>
			<div class="bRow2">
				<div class="bTitle">Dedicated Mobile site</div>
				<div class="bCost">&#8377; 4000</div>	
			</div>

			<div class="bRow2">
				<div class="bTitle">Email Configuration for professional emails</div>
				<div class="bCost">&#8377; 2000</div>	
			</div>
			<div class="bRow2">
				<div class="bTitle">Website statistics (non-plugin)</div>
				<div class="bCost">&#8377; 4000</div>	
			</div>
			<div class="bRow2">
				<div class="bTitle">Banking portal</div>
				<div class="bCost">&#8377; 10,000</div>	
			</div>
			<div class="bRow2">
				<div class="bTitle">Social media management: facebook, Instagram, youtube, twitter, etc</div>
				<div class="bCost">&#8377; 4000/mo</div>	
			</div>

		</div>
	</div>&nbsp;
</body>
</html>