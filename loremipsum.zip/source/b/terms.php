Terms and Conditions of Usage
~ to be implemented