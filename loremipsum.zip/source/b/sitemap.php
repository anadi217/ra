Sitemap for Browser Indexing
~ Bonus ++ feature