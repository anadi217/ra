<?php session_start();
$_SESSION["blocked"]=true;
//add to database of flagged IP addresses
?>