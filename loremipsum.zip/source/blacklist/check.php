<?php //session_start(); will already be started by the program calling
$_SESSION["blocked"]=false; 
//cross-check database for flagged IP addresses
?>