<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes">
<link rel="icon" href="/icon.ico">
<link href="https://fonts.googleapis.com/css?family=Lato:300" rel="stylesheet">
<style type="text/css">
html,body{margin:0;padding:0;} body{font-family:'Lato',sans-serif; overflow-x:hidden;}
</style>