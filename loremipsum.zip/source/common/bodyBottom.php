<style type="text/css">
#bottomBar{
	width: 100vw;
	text-align: center; background-color: #fff; 
	box-shadow:0 1px 4px rgba(0,0,0,0.3) inset;
	font-family: sans-serif; padding-top: 1em;
}
#social{display: inline-block; padding: 1em 0 0.5em;}
.snButton{
	display: inline-block; height:1.25rem;
	opacity: 0.7; border-radius: 15%;
	transition: .1s ease;
}
.snButton:hover{opacity: 1; transition: .1s ease; }
#end{
	font-size: 0.8em; line-height: 1.5em; 
	padding: 0.5em; display: inline-block; 
	border-top:1px solid #ccc;
}
#end a{color: #777;text-decoration: none;}
</style>
<div id="bottomBar">
	<div id="social">
		<a href="http://www.facebook.com" target="_blank"><img class="snButton" src="/source/b/img/fb.png"></a>&ensp;
		<a href="http://www.instagram.com" target="_blank"><img class="snButton" src="/source/b/img/insta.png"></a>&ensp;
		<a href="http://www.youtube.com" target="_blank"><img class="snButton" src="/source/b/img/ytb.png"></a>&ensp;
		<a href="http://www.twitter.com" target="_blank"><img class="snButton" src="/source/b/img/twitter.png"></a>&ensp;
		<a href="mailto:anadi217@gmail.com" target="_blank"><img class="snButton" src="/source/b/img/mail.png"></a>&ensp;
	</div><br>
	<div id="end">
		<a href="/source/b/about.php" target="_blank">About</a>&ensp;|&ensp;
		<a href="/source/b/contact.php" target="_blank">Contact Us</a>&ensp;|&ensp;
		<a href="/source/b/sitemap.php" target="_blank">Sitemap</a>&ensp;|&ensp;
		<a href="/source/b/terms.php" target="_blank">Terms of Use</a>&ensp;|&ensp; 
		<a href="/source/b/privacy.php" target="_blank">Privacy Policy</a>&ensp;|&ensp; 
		<a href="http://m.loremipsum.redexpresskolkata.com" target="_blank">Mobile Site</a>&ensp;|&ensp; 
		<a href="http://n.loremipsum.redexpresskolkata.com" target="_blank">No Script Site</a>
		<br>
		&copy; <a href="/source/b/copyright.php" target="_blank">Copyright 2010 Enactus Pvt Ltd, 2010</a>&ensp;|&ensp;
		<a href="/source/b/certificate.php" target="_blank">HACCP ISO22000:2005 certified</a>
	</div>
</div>