<style type="text/css">
#topRight{
	position: absolute; text-align: right;
	top: 1em; right:1em; z-index: 999;
}
.topRightButton{
	height: 3rem; width: 3rem;
	margin-right: 1ch;
	cursor: pointer;
	fill: white;
}
#appsMenuContainer{
	text-align: right; display: none;
	min-width: 15ch;
}
#appsMenuContainer>svg{
	padding-right: 1em;
	height: 1em;
	margin:0; fill: white;
}
#appsMenu{
	padding: 8px; 
	display: flex; flex-flow: row wrap;
	justify-content: space-around;
	background-color: white;
	margin-top:-5px;
	max-width: 20ch;
	font-family: sans-serif;
}
#appsMenu>div>svg{
	height: 3em; width: 3em;
	fill:#ccc; cursor: pointer;
}
#appsMenu>div{
 text-align: center;
 margin:10px;
}
</style>
<div id="topRight">
	<a href="/i/"><svg viewBox="0 0 24 24" class="topRightButton" xmlns="http://www.w3.org/2000/svg"> <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 3c1.66 0 3 1.34 3 3s-1.34 3-3 3-3-1.34-3-3 1.34-3 3-3zm0 14.2c-2.5 0-4.71-1.28-6-3.22.03-1.99 4-3.08 6-3.08 1.99 0 5.97 1.09 6 3.08-1.29 1.94-3.5 3.22-6 3.22z"/> </svg></a>
	<svg class="topRightButton" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" onclick="topRightMenuToggle();"> <path d="M4 8h4V4H4v4zm6 12h4v-4h-4v4zm-6 0h4v-4H4v4zm0-6h4v-4H4v4zm6 0h4v-4h-4v4zm6-10v4h4V4h-4zm-6 4h4V4h-4v4zm6 6h4v-4h-4v4zm0 6h4v-4h-4v4z"/> </svg>
	<div id="appsMenuContainer">
		<svg  viewBox="9 9 6 3" xmlns="http://www.w3.org/2000/svg"> <path d="M7 14l5-5 5 5z"/> </svg>
		<div id="appsMenu">
			<div onclick="window.location.href='/';"><svg  viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"> <path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"/> </svg><br>Home</div>
			<div onclick="window.location.href='/source/b/contact.php';"><svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"> <path d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z"/> </svg><br>Contact</div>
			<div onclick="window.location.href='/filelist.php';"><svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"> <path d="M13 12h7v1.5h-7zm0-2.5h7V11h-7zm0 5h7V16h-7zM21 4H3c-1.1 0-2 .9-2 2v13c0 1.1.9 2 2 2h18c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 15h-9V6h9v13z"/> </svg><br>All files</div>
			<div onclick="window.location.href='/features.php';"><svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"> <path d="M13 13v8h8v-8h-8zM3 21h8v-8H3v8zM3 3v8h8V3H3zm13.66-1.31L11 7.34 16.66 13l5.66-5.66-5.66-5.65z"/></svg><br>Features</div>
		</div>
	</div>	
</div>
<script type="text/javascript">
	topRightMenuToggleN=false;
	function topRightMenuToggle() {
		topRightMenuToggleN=!topRightMenuToggleN;
		if(topRightMenuToggleN){document.getElementById('appsMenuContainer').style.display="block";}
		else{document.getElementById('appsMenuContainer').style.display="none";}

	}
</script>