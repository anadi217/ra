<?php 
session_set_cookie_params(0);session_start();
if (!isset($_SESSION["blocked"])){include $_SERVER['DOCUMENT_ROOT'].'/source/blacklist/check.php';}
if($_SESSION["blocked"]===true){header("Location: /DDoS.php");exit();}
if(	!isset($_SESSION["client_id"])&&
	isset($_COOKIE["client_username"])&&
	isset($_COOKIE["client_password"])&&
	isset($_COOKIE["h_off"])&&
	isset($_COOKIE["client_name"])
	){
	$a = $_COOKIE["client_username"];
	$b = $_COOKIE["client_password"];
	$c = $_COOKIE["h_off"]; //additional checks
	$d = $_COOKIE["client_name"]; //additional checks

	function exitX() //attempt to manipulate cookies => possible hacker => immediate blacklist
	{	include $_SERVER['DOCUMENT_ROOT'].'/source/blacklist/blacklist.php';
		$_SESSION["blocked"]=true; unset($_SESSION["autologin"]);
		header("Location: /DDoS.php");exit();
	}
	if (!isset($_SESSION["autologin"]) ) {$_SESSION["autologin"]=0; }
	$_SESSION["autologin"]++; if ($_SESSION["autologin"]==2){exitX();}

	if(!preg_match("/^[a-zA-Z][a-zA-Z\d]*[\._]?[a-zA-Z\d]+$/",$a)||strlen($a)<5||strlen($a)>32||
		preg_match("/[^\w\d\@\#\:\.\/]/",$b)||strlen($b)<5|| strlen($b)>32||
		!preg_match("/[a-z]/",$b)|| !preg_match("/[A-Z]/",$b)||
		!preg_match("/[\d]/",$b)|| !preg_match("/[\@\#\:\.\/\_]/",$b)
		){exitX();}

	$conn =	new mysqli("103.21.58.5:3306","loremipsum","##@LoremIpsum@##","loremipsum") 
		or exit("Error Connection failed: " . $conn->connect_error);
	$result = $conn->query("SELECT id FROM login WHERE username='".$a."' AND password='".$b."';");
	if($result->num_rows!==1){exitX();}
	$row = $result->fetch_assoc(); $e=$row["id"];
	$result = $conn->query("SELECT ida,rank FROM account WHERE 
		id=".$e." AND 
		h_off=".$c." AND 
		name='".$d."';
		");
	if($result->num_rows===1){
		$row = $result->fetch_assoc(); $f=$row["ida"]; $g=$row["rank"];
		$conn->close();
		$_SESSION["client_id"] = $e;
		$_SESSION["client_rank"] = $g;
		$_SESSION["client_ida"] = $f;
	}
}
?>