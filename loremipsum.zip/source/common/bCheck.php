<?php //session_start(); will already be started by the program calling
if (!isset($_SESSION["blocked"])){include $_SERVER['DOCUMENT_ROOT'].'/source/blacklist/check.php';}
if($_SESSION["blocked"]===true){header("Location: /DDoS.php");exit();}
?>