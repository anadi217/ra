<?php session_start();
if(!isset($_SESSION["blocked"])){session_unset();session_destroy();}
else{
	if($_SESSION["blocked"]==true){header("Location: /DDoS.php");}
	else if($_SESSION["blocked"]==false){session_unset();session_destroy();}
}
foreach ($_COOKIE as $key => $value) {setcookie($key,false,0,"/");}
?>