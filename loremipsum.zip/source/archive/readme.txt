Terms used
==========
viewer 	- user who is not logged in / does not have an account
reader 	- user who is logged in (& can optionally maintain profile)
author 	- can upload documents (& optionally maintain profile)
admin 	- can add/remove authors

Naming conventions used
========================
1. All html files generated from uploaded documents are by named by converting idf (unique document id) from base 10 to base 36 {done to shorten the url and filename}
2. All related images are saved as [base36id]_[imgid].* {extensions: svg/png/jpeg/gif}

DATABASE STRUCTURE
==================
Server		=	103.21.58.5:3306
Db name		=	loremipsum
Type 		=	MySQL
Username 	=	loremipsum
Password 	= 	##@LoremIpsum@##

TABLE1: files
-------------
idf 		int   			#//{unique file ID} max:4.3 Billion (unsigned auto_increment primary key)
ida 		smallint 		#//{unique author ID} max:65535 (unsigned)
mdate 		timestamp 		#//{date modified} autoupdate, returns as YYYY-MM-DD HH:MM:SS
ftype 		char(3) 		#//{file type}(not null)
title 		tinytext		#//max:255 charactters
description text 			
tags 		text 			#//{tags for indexing, # or comma separated}

TABLE2: login
--------------
id			mediumint 			#//unsigned primary key,
username	varchar(32), 		#//unique
password	varchar(32),	

TABLE2: account
---------------
id			mediumint			#//{unique reader ID} max:16.7 Million (unsigned auto_increment primary key)
ida			smallint DEFAULT 0,
pre			bit(2) DEFAULT 0b0, #//array("Mr","Ms","Dr","")
name		varchar(64),
rank		bit(2) DEFAULT 0b0	#//array(viewer,author,admin,author_request)
h_off		bit(1) DEFAULT 0b0	#//history toggle
email		varchar(64), 
birthday	DATE,	 			#//storage format YYYY-MM-DD
country		tinyint UNSIGNED,	#//alphabetically sorted array of Wikipedia's top most populated countries 
phone		char(10), 			#//dont-use varchar or int
bookmarks	text, 				#//comma separated base36fileIDs
read_later	text, 				#//comma separated base36fileIDs
history		text, 				#//comma separated base36fileIDs
bookmarks	text, 				#//comma separated base36fileIDs
cdate		timestamp 			#//auto-assign
designation	varchar(176) 		#//character limit = 255-64-4 = 187-11 = 176, DEFAULT NULL
);