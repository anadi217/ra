CREATE TABLE files(
	idf int UNSIGNED AUTO_INCREMENT PRIMARY KEY, 
	ida smallint UNSIGNED, 
	mdate TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, 
	ftype char(4), 
	title tinytext, 
	description TEXT, 
	tags TEXT 
);
CREATE TABLE login(
	id mediumint UNSIGNED PRIMARY KEY, 
	username varchar(32), UNIQUE (username),
	password varchar(32) 
);
CREATE TABLE account(
	id mediumint UNSIGNED AUTO_INCREMENT PRIMARY KEY, 
	ida smallint DEFAULT 0, 
	pre bit(2) DEFAULT 0b0,
	name varchar(64), 
	rank bit(1) DEFAULT 0b0,
	h_off bit(1) DEFAULT 0b0,
	email varchar(64), 
	birthday DATE, 
	country tinyint UNSIGNED, 
	phone char(10), 
	bookmarks text, 
	history text, 
	cdate TIMESTAMP DEFAULT CURRENT_TIMESTAMP, 
	designation varchar(176) DEFAULT NULL 
);


#DELETE FROM account; ALTER TABLE account AUTO_INCREMENT=1;