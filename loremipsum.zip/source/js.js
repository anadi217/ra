var carrPoint, carrDir;
function dotAct(elem) {
    var a = document.getElementById('dots').getElementsByTagName('button');
    for (i = a.length-1; i >= 0; i--) {a[i].classList.remove('dotAct');}
    elem.classList.add('dotAct');
	carrPoint = parseInt((elem.id).slice(-1));
	for (var i = carrPoint; i > 0; i--) {document.getElementsByClassName('carouselDummy')[i-1].style.width="0"; }
	for (var j = carrPoint; j <=2; j++) {document.getElementsByClassName('carouselDummy')[j].style.width="100vw"; }
}
if (window.XMLHttpRequest) {xmlhttp = new XMLHttpRequest();} 
else {xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");}
xmlhttp.open("GET","/source/common/phpHead.php",true);
xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xmlhttp.send();